using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Admin_frmAddPolicy : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ddlCId.DataSource = InsurenceCompany.Getcompanies();
            ddlCId.DataTextField = "companyname";
            ddlCId.DataValueField ="companyid";
            ddlCId.DataBind();
            ddlCId.Items.Insert(0, "--Select--");
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        txtAmt.Text = "";
       txtEmi.Text = "";
        txtPDesc.Text = "";
        txtPtypeName.Text = "";
        lblMsg.Text = "";
        txtMedical.Text = "";

        for (int i = 0; i < ddlCId.Items.Count; i++)
        {
            ddlCId.Items[i].Selected = false;
        }
        ddlCId.Items[0].Selected = true;
     
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        if (ddlCId.SelectedItem.ToString() !="--Select--")
        {
            AddPolicy.InsertPolicy(txtPtypeName.Text, txtPDesc.Text, Convert.ToDecimal(txtAmt.Text), Convert.ToDecimal(txtEmi.Text), int.Parse(ddlCId.SelectedValue), txtMedical.Text);
            lblMsg.Text = "Policy Added.Are U add one more?";
        }
        else
            lblMsg.Text = "U haven't select policy";
    }
}
