using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Admin_frmAddPoliyToEmployee : System.Web.UI.Page
{

    protected void btncancel_Click(object sender, EventArgs e)
    {
        txt.Text = "";
        TextBox2.Text="";
        TextBox3.Text = "";
        TextBox4.Text = "";
        txtmedical.Text = "";
        TextBox8.Text = "";
        lblmsg.Text = "";
        txtduration.Text = "";

    }
    AddPoliciesOnEmployees obj = new AddPoliciesOnEmployees();
    protected void Page_Load(object sender, EventArgs e)
    {
        GMDatePicker1.Attributes.Add("readOnly", "readOnly()");
        GMDatePicker2.Attributes.Add("readOnly", "readOnly()");
        if (!IsPostBack)
        {
            DataSet ds = AddPolicy.Getpolicies();
            DataSet ds1 = CompanyDeatails.getcomanyid();
            ddlpolicyid.DataSource = ds;
         ddlpolicyid.DataTextField = "policyid";
         ddlpolicyid.DataBind();
         ddlpolicyid.Items.Insert(0, "--Select--");
         ViewState["policy"] = ds;

         ddlcompanyid.DataSource = ds1;
         ddlcompanyid.DataTextField = "companyid";
         ddlcompanyid.DataBind();
         ddlcompanyid.Items.Insert(0, "--Select--");
         ViewState["company"] = ds1;
        }
        if (Request.QueryString["empno"] != null)
            txt.Text = Request.QueryString["empno"].ToString();
    }
    protected void ddlpolicyid_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlpolicyid.SelectedItem.ToString() != "--Select--")
        {
            DataSet ds = (DataSet)ViewState["policy"];
            DataRow rec = ds.Tables[0].Select("policyid=" + ddlpolicyid.SelectedItem)[0];
            TextBox2.Text = rec[1].ToString();
            TextBox3.Text = rec[2].ToString();
            TextBox4.Text = rec[3].ToString();
            txtmedical.Text = rec[4].ToString();
        }
        else
        {
            TextBox2.Text = "";
            TextBox4.Text = "";
            TextBox3.Text = "";
        }
    }
    protected void ddlcompanyid_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlcompanyid.SelectedItem.ToString() != "--Select--")
        {
            DataSet ds = (DataSet)ViewState["company"];
            DataRow rec = ds.Tables[0].Select("Companyid='" + ddlcompanyid.SelectedItem + "'")[0];
            TextBox8.Text = rec[1].ToString();
        }
        else
            TextBox8.Text = "";
    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        if (ddlpolicyid.SelectedItem.ToString() != "--Select--"  && ddlcompanyid.SelectedItem.ToString() != "--Select--")
        obj.Empno = txt.Text;
        obj.Policyid = int.Parse(ddlpolicyid.SelectedItem.ToString());
        obj.Policyname = TextBox2.Text;
        obj.Policyamount = Convert.ToDecimal(TextBox3.Text);
        obj.Policyduration = Convert.ToDecimal(txtduration .Text);
        obj.Emi = Convert.ToDecimal(TextBox4.Text);
        obj.Pstartdate =GMDatePicker1.Date;
        obj.Penddate = GMDatePicker2.Date;
        obj.Companyid =ddlcompanyid.SelectedItem.ToString();
        obj.Companyname=TextBox8.Text;
        obj.Medical = txtmedical.Text;
        obj.InsertPolicyOnEmployee();
                lblmsg.Text = "policy is added to employee";
    }
    protected void txt_TextChanged(object sender, EventArgs e)
    {

    }
}
