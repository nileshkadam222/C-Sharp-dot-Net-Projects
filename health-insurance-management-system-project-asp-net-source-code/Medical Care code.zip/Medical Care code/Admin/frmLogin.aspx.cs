using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Admin_frmLogin : System.Web.UI.Page
{
    string adminlgin;
    protected void Page_Load(object sender, EventArgs e)
    {
        txtuid.Focus();
    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            adminlgin = AdminLogin.AdminLogIn(txtuid.Text, txtpwd.Text);
            if (!String.IsNullOrEmpty(adminlgin))

                Response.Redirect("~/Admin/frmHomepage.aspx");

            else
                lblMsg.Text = "Invalid Username or Password";
            txtpwd.Focus();
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
}
