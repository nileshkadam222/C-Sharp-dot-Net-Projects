using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Admin_frmAddDesignation : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        txtcname.Focus();
    }
    InsurenceCompany InsurenceObj = new InsurenceCompany();
    private void Filldata()
    {
        InsurenceObj.Cname = txtcname.Text;
        InsurenceObj.Phone = txtpno.Text;
        InsurenceObj.Url = txtcurl.Text;
        InsurenceObj.Address = txtaddress.Text;
    
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
       
        txtcname.Text = "";
        txtaddress.Text = "";
        txtpno.Text = "";
        txtcurl.Text = "";
        lblmsg.Text = "";
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        Filldata();
       InsurenceObj.InsertCompanydetails();
        lblmsg.Text = "Company added succussfull";

    }
}
