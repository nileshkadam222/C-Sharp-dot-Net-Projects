using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Admin_frmAddEmployee : System.Web.UI.Page
{  
    EmpRegister RegObj = new EmpRegister();
    protected void Page_Load(object sender, EventArgs e)
    {
        
        GMDatePicker1.Attributes.Add("readOnly", "readOnly()");
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
       
        txtdesignation.Text = "";
        txtfname.Text = "";
        txtlname.Text = "";
        txtusername.Text = "";
        txtpwd.Text = "";
        txtaddress.Text = "";
        txtcontactno.Text = "";
        txtstate.Text = "";
        txtcountry.Text = "";
        txtcity.Text = "";
        txtsalary.Text = "";
        lblmsg.Text = "";

       
     
    }
    private void Filldata()
    {
        RegObj.Designation = txtdesignation.Text;
        RegObj.Firstname = txtfname.Text;
        RegObj.Lastname = txtlname.Text;
        RegObj.Username = txtusername.Text;
        RegObj.Password = txtpwd.Text;
        RegObj.Address = txtaddress.Text;
        RegObj.Contactno = txtcontactno.Text;
        RegObj.State = txtstate.Text;
        RegObj.Country = txtcountry.Text;
        RegObj.City = txtcity.Text;
        RegObj.Joindate = GMDatePicker1.Date;
        RegObj.Salary = Convert.ToDecimal(txtsalary.Text);

    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        Filldata();
        RegObj.InsertEmpRegister();
        lblmsg.Text = "Record added.Are you add one more Employee";
    }
}
