using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Admin_frmForStatus : System.Web.UI.Page
{
    int empno;
 
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["id"] != null)
            empno = int.Parse(Request.QueryString["id"].ToString());
        string status = AddPoliciesOnEmployees.Getstatus(empno);
        if (status == "ok")
        {
            lblstatus.Text = "Haven't take any policy now? add click here";
            Label1.Text = "";
            Label2.Text = "";
            Label3.Text = "";
            Label4.Text = "";
            Label5.Text = "";
            Label6.Text = "";
            Label7.Text = "";
            Label8.Text = "";
            Label9.Text = "";
            Label10.Text = "";
            Label11.Text = "";
            Label12.Text = "";
            Label13.Text = "";
            Label14.Text = "";
            Label15.Text = "";
            Label16.Text = "";
            Label17.Text = "";
            Label18.Text = "";
        }
        else if(status =="notok")
        {
            int i = AddPoliciesOnEmployees.getcoutnt(empno);
            if (i > 0)
            {
                DataRow r = AddPoliciesOnEmployees.GetPolicyOnEmployeedetails(empno);
                Label2.Text = r["policyid"].ToString();
                Label4.Text = r["policyname"].ToString();
                Label6.Text = r["policyamount"].ToString();
                Label8.Text = r["policyduration"].ToString();
                Label10.Text = r["emi"].ToString();
                Label12.Text = r["pstartdate"].ToString();
                Label14.Text = r["penddate"].ToString();
                Label16.Text = r["companyid"].ToString();
                Label18.Text = r["companyname"].ToString();
                lblstatus.Text = "he has a policy here is the details";
                btnadd.Enabled = false;

            }

            else
            {
                lblstatus.Text = "He joined recently";
                btnadd.Enabled = false;
                Label1.Text = "";
                Label2.Text = "";
                Label3.Text = "";
                Label4.Text = "";
                Label5.Text = "";
                Label6.Text = "";
                Label7.Text = "";
                Label8.Text = "";
                Label9.Text = "";
                Label10.Text = "";
                Label11.Text = "";
                Label12.Text = "";
                Label13.Text = "";
                Label14.Text = "";
                Label15.Text = "";
                Label16.Text = "";
                Label17.Text = "";
                Label18.Text = "";
            }

        }

    }

    
    protected void btnadd_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Admin/frmAddPoliyToEmployee.aspx?empno=" + empno);
    }
    protected void btndeleteRequest_Click(object sender, EventArgs e)
    {

    }
}
