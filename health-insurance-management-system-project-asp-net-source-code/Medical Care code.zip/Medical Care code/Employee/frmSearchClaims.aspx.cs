using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Employee_frmSearchClaims : System.Web.UI.Page
{
    int empno;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["empno"] != null)
            empno = int.Parse(Session["empno"].ToString());

        if (!IsPostBack)
        {
         DataRow r = AddPoliciesOnEmployees.GetPolicyOnEmployee(empno).Tables[0].Rows[0];
            Label7.Text = r["policyname"].ToString();
            Label8.Text=r["policyid"].ToString();
            Label9.Text = r["policyamount"].ToString();
            Label10.Text = r["TotalAmount"].ToString();
            Label11.Text = r["pstartdate"].ToString();
         }
    }
    protected void btnapplicy_Click(object sender, EventArgs e)
    {
        if (ddlReason.SelectedItem.ToString() != "--Select--")
        {
            if (ddlReason.SelectedItem.Text == "Death")
            {
                Session["Reason"] = ddlReason.SelectedItem.Text;
                Response.Redirect("frmDeathCliam.aspx");
            }
            else if (ddlReason.SelectedItem.Text == "Accident")
            {
                Session["Reason"] = ddlReason.SelectedItem.Text;
                Response.Redirect("frmAccidentClaim.aspx");
            }
            else
            {
                Session["Reason"] = ddlReason.SelectedItem.Text;
                Response.Redirect("frmCompleteClaim.aspx");
            }

        }
        else
            lblmsg.Text = "U have to select the reason";
    }
}
