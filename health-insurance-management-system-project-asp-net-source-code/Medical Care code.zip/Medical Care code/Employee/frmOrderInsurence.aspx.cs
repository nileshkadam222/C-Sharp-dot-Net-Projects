using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Employee_frmOrderInsurence : System.Web.UI.Page
{
    string empno;
    DataSet ds;
    PolicyRequestDetails plyreqOBj=new PolicyRequestDetails();
    protected void Page_Load(object sender, EventArgs e)
    { if (Session["empno"]!=null)
        empno = Session["empno"].ToString();
    if (!IsPostBack)
    {
      ds = AddPolicy.ShowPolicies();
      ViewState["ds"] = ds;
        ddlpid.DataSource= ds;
        ddlpid.DataTextField = "policyid";
        ddlpid.DataValueField = "policyid";
        ddlpid.DataBind();
        ddlpid.Items.Insert(0, "--Select--");
    }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        txtpamount.Text = "";
        txtpname.Text = "";
        txtEmi.Text = "";
        txtCname.Text = "";
        txtCid.Text = "";
        lblmsg.Text = "";
  
    }
    void Filldata()
    {
        plyreqOBj.Empno =int.Parse( Session["empno"].ToString());
        plyreqOBj.Policyid = int.Parse(ddlpid.SelectedItem.ToString());
        plyreqOBj.Policyname = txtpname.Text ;
        plyreqOBj.Amount = Convert.ToDecimal(txtpamount.Text);
        plyreqOBj.Emi = Convert.ToDecimal(txtEmi.Text);
        plyreqOBj.Requestdate = GMDatePicker1.Date;
        plyreqOBj.Companyid = int.Parse(txtCid.Text);
        plyreqOBj.Companyname = txtCname.Text;

    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        Filldata();
        plyreqOBj.InsertPolicyRequest();
        lblmsg.Text = "Request is sended to Admin";
    }
    protected void ddlpid_SelectedIndexChanged(object sender, EventArgs e)
    {
      DataSet   ds = (DataSet)ViewState["ds"];
      if (ddlpid.SelectedItem.ToString() != "--Select--")
      {
          DataRow r = ds.Tables[0].Select("policyid=" + ddlpid.SelectedItem)[0];
          txtCname.Text = r[6].ToString();
          txtCid.Text = r[0].ToString();
          txtpname.Text = r[2].ToString();
          txtpamount.Text = r[4].ToString();
          txtEmi.Text = r[5].ToString();
      }
      else
      {
          txtCname.Text = "";
          txtCid.Text = "";
          txtpname.Text = "";
          txtpamount.Text = "";
          txtEmi.Text = "";
      }

    }
}
