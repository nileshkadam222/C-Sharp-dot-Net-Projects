using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Employee_frmConformationClaim : System.Web.UI.Page
{
    int empno;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["empno"] != null)
            empno = int.Parse(Session["empno"].ToString());

        if (!IsPostBack)
        {
            DataRow r = AddPoliciesOnEmployees.GetPolicyOnEmployee(empno).Tables[0].Rows[0];
           LblEmpId .Text = Session["empno"].ToString();
            LblPolicyId .Text = r["policyid"].ToString();
            LblClaimingDate.Text = DateTime.Now.ToString();
            LblCause.Text = Session["Reason"].ToString();
           LblClaimAmount .Text = AddPoliciesOnEmployees.GetClaimAmountForAccident(empno).ToString();
            

        }


    }
}
