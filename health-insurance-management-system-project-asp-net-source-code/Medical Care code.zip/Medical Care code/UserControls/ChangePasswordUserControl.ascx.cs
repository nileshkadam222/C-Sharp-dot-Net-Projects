using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class ForgotpwdUserControl : System.Web.UI.UserControl
{
   int empno;
    string username;
    protected void Page_Load(object sender, EventArgs e)
    {
        empno = int.Parse(Session["empno"].ToString());

    }
    protected void btnlogin_Click(object sender, EventArgs e)
    {
      username = Session["password"].ToString();
        if (txtpwd.Text == username)
        {
            EmpRegister.ChangePassword(txtnewpwd.Text,empno);
          
            lblMsg.Text = "Your Password successfully changed";
        }
        else
            lblMsg.Text = "Incurrect  old password ?";
    }
}
