using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for AddPoliciesOnEmployees
/// </summary>
public class AddPoliciesOnEmployees
{
	public AddPoliciesOnEmployees()
	{
		
	}
    string empno;

    public string Empno
    {
        get { return empno; }
        set { empno = value; }
    }
    int policyid;

    public int Policyid
    {
        get { return policyid; }
        set { policyid = value; }
    }
    string policyname;

    public string Policyname
    {
        get { return policyname; }
        set { policyname = value; }
    }
    decimal policyamount;

    public decimal Policyamount
    {
        get { return policyamount; }
        set { policyamount = value; }
    }
    decimal policyduration;

    public decimal Policyduration
    {
        get { return policyduration; }
        set { policyduration = value; }
    }
    decimal emi;

    public decimal Emi
    {
        get { return emi; }
        set { emi = value; }
    }
    DateTime pstartdate;

    public DateTime Pstartdate
    {
        get { return pstartdate; }
        set { pstartdate = value; }
    }
    DateTime penddate;

    public DateTime Penddate
    {
        get { return penddate; }
        set { penddate = value; }
    }
    string companyid;

    public string Companyid
    {
        get { return companyid; }
        set { companyid = value; }
    }
    string companyname;

    public string Companyname
    {
        get { return companyname; }
        set { companyname = value; }
    }
    string medical;

    public string Medical
    {
        get { return medical; }
        set { medical = value; }
    }
    public void InsertPolicyOnEmployee()
    {
        SqlParameter[] p = new SqlParameter[11];

        p[0]=new SqlParameter("@empno",SqlDbType.VarChar,10);
        p[0].Value=this.empno;

        p[1]=new SqlParameter("@policyid",SqlDbType.Int);
        p[1].Value = this.policyid;

        p[2]=new SqlParameter("@policyname",SqlDbType.VarChar,50);
        p[2].Value = this.policyname;

        p[3]=new SqlParameter("@policyamount",SqlDbType.Money );
        p[3].Value = this.policyamount;

        p[4]=new SqlParameter("@policyduration",SqlDbType.Decimal);
        p[4].Value = this.policyduration;
        p[5]=new SqlParameter("@emi",SqlDbType.Decimal );
        p[5].Value = this.emi;

        p[6]=new SqlParameter("@pstartdate",SqlDbType.DateTime );
        p[6].Value = this.pstartdate;
        p[7]=new SqlParameter("@penddate",SqlDbType.DateTime );
        p[7].Value = this.penddate;

        p[8]=new SqlParameter("@companyid",SqlDbType.VarChar,30);
        p[8].Value=this.companyid;

        p[9]=new SqlParameter("@companyname",SqlDbType.VarChar,50);
        p[9].Value = this.companyname;

        p[10]=new SqlParameter("@medicalid",SqlDbType.VarChar,50);
        p[10].Value=this.medical;
        SqlHelper.ExecuteNonQuery(Connection.Con, CommandType.StoredProcedure, "SPAddPolicyOnEmployee", p);

    }
    public static string  Getstatus(int eid)
    {
        SqlParameter[] p = new SqlParameter[2];
                 p[0]=new SqlParameter ("@eid", SqlDbType.Int);
                 p[0].Value = eid;
                 p[1] = new SqlParameter("@status", SqlDbType.VarChar, 10);
                 p[1].Direction = ParameterDirection.Output;
        SqlHelper.ExecuteNonQuery(Connection.Con, CommandType.StoredProcedure, "SpStatus", p);
        return p[1].Value.ToString();
    }
    public static DataSet  GetPolicyOnEmployee(int empno)
    {
       return SqlHelper.ExecuteDataset(Connection.Con, CommandType.Text, "select PolicyName,PolicyId,Policyamount,pstartdate,  Emi*datediff(Month,pstartdate,getdate()) as TotalAmount from policiesonemployees where empno="+empno);
       
    }
    public static DataSet GetPolicyOnEmployee(string designation)
    {
        SqlParameter p = new SqlParameter("@desig", SqlDbType.VarChar, 50);
        p.Value = designation;
        return SqlHelper.ExecuteDataset(Connection.Con, CommandType.StoredProcedure, "GetPolicyOnEmp", p);
    }

    public static DataSet GetEmployeeOnPolicy(string designation)
    {
        SqlParameter p = new SqlParameter("@policyname", SqlDbType.VarChar, 50);
        p.Value = designation;
        return SqlHelper.ExecuteDataset(Connection.Con, CommandType.StoredProcedure, "SpGetEmpByPolicy", p);
    }
    public static int getcoutnt(int empno)
    {
        return  (int)SqlHelper.ExecuteScalar(Connection.Con, CommandType.Text, "select count(*) from policiesonemployees where empno=" + empno);
    }
    public static int GetClaimAmountForAccident(int empno)
    {
        SqlParameter[] p = new SqlParameter[2];
        p[0] = new SqlParameter("@EmpNo", SqlDbType.Int);
        p[0].Value = empno;

        p[1] = new SqlParameter("@ClaimAmount", SqlDbType.Int);
        p[1].Direction = ParameterDirection.Output;
        SqlHelper.ExecuteNonQuery(Connection.Con, CommandType.StoredProcedure, "CalCulateClaimForAcccedent",p);
        return int.Parse (p[1].Value.ToString ());
    }

    public static int GetClaimAmountForDeath(int empno)
    {
        SqlParameter[] p = new SqlParameter[2];
        p[0] = new SqlParameter("@EmpNo", SqlDbType.Int);
        p[0].Value = empno;

        p[1] = new SqlParameter("@ClaimAmount", SqlDbType.Int);
        p[1].Direction = ParameterDirection.Output;
        SqlHelper.ExecuteNonQuery(Connection.Con, CommandType.StoredProcedure, "CalCulateClaimForDeath", p);
        return int.Parse(p[1].Value.ToString());
    }


    public static int GetClaimAmountForComplePolicy(int empno)
    {
        SqlParameter[] p = new SqlParameter[2];
        p[0] = new SqlParameter("@EmpNo", SqlDbType.Int);
        p[0].Value = empno;

        p[1] = new SqlParameter("@ClaimAmount", SqlDbType.Int);
        p[1].Direction = ParameterDirection.Output;
        SqlHelper.ExecuteNonQuery(Connection.Con, CommandType.StoredProcedure, "CalculateClaimComplete", p);
        return int.Parse(p[1].Value.ToString());
    }

    public static DataRow GetPolicyOnEmployeedetails(int empno)
    {
        DataRow dr = (DataRow)SqlHelper.ExecuteDataset(Connection.Con, CommandType.Text, "select *from policiesonemployees where empno=" + empno).Tables[0].Rows[0];
        if (dr != null)
            return dr;
        else
            return dr = null;
    }
}
