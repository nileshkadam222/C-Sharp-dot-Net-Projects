using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;


/// <summary>
/// Summary description for EmpOwnDetails
/// </summary>
public class EmpOwnDetails
{
	public EmpOwnDetails()
	{
		
	}

    
    string _fname;

    public string Fname
    {
        get { return _fname; }
        set { _fname = value; }
    }
    string _lname;

    public string Lname
    {
        get { return _lname; }
        set { _lname = value; }
    }
    string _qualification;

    public string Qualification
    {
        get { return _qualification; }
        set { _qualification = value; }
    }
    DateTime _dataofbirth;

    public DateTime Dataofbirth
    {
        get { return _dataofbirth; }
        set { _dataofbirth = value; }
    }
    string _phno;

    public string Phno
    {
        get { return _phno; }
        set { _phno = value; }
    }
    string _homephno;

    public string Homephno
    {
        get { return _homephno; }
        set { _homephno = value; }
    }
    string _emailid;

    public string Emailid
    {
        get { return _emailid; }
        set { _emailid = value; }
    }
    string _peraddress;

    public string Peraddress
    {
        get { return _peraddress; }
        set { _peraddress = value; }
    }
    string _preaddress;

    public string Preaddress
    {
        get { return _preaddress; }
        set { _preaddress = value; }
    }
    string _empid;

    public string Empid
    {
        get { return _empid; }
        set { _empid = value; }
    }
   
    
public void InsertEmpOwnDetails()
    {
    
        SqlParameter[] p = new SqlParameter[10];
        p[0] = new SqlParameter("@fname", SqlDbType.VarChar, 50);
        p[0].Value = this._fname;

        p[1]=new SqlParameter("@lname",SqlDbType.VarChar ,50);
       p[1].Value =this._lname;

        p[2]=new SqlParameter("@qualification",SqlDbType.VarChar ,10);
       p[2].Value =this._qualification;

       p[3] = new SqlParameter("@dataofbirth", SqlDbType.DateTime);
       p[3].Value =this._dataofbirth;

        p[4]=new SqlParameter("@phno",SqlDbType.VarChar ,20);
       p[4].Value =this._phno;

        p[5]=new SqlParameter("@homephno",SqlDbType.VarChar ,20);
       p[5].Value =this._homephno;

        p[6]=new SqlParameter("@emailid",SqlDbType.VarChar ,50);
       p[6].Value =this._emailid;

        p[7]=new SqlParameter("@peraddress",SqlDbType.VarChar ,250);
       p[7].Value =this.Peraddress ;

        p[8]=new SqlParameter("@preaddress",SqlDbType.VarChar ,250);
        p[8].Value =this._preaddress;

       p[9]=new SqlParameter("@empid",SqlDbType.VarChar ,10);
       p[9].Value =this._empid  ;

       SqlHelper.ExecuteNonQuery(Connection.Con, CommandType.StoredProcedure, "SpInsertEmpOwnDetails", p);
        }
    public void UpdateEmpOwnDetails()
    {
        SqlParameter[] p = new SqlParameter[9];
        p[0] = new SqlParameter("@fname", SqlDbType.VarChar, 50);
        p[0].Value = this._fname;

        p[1] = new SqlParameter("@lname", SqlDbType.VarChar, 50);
        p[1].Value = this._lname;

        p[2] = new SqlParameter("@qualification", SqlDbType.VarChar, 10);
        p[2].Value = this._qualification;
   
       

        p[3] = new SqlParameter("@phno", SqlDbType.VarChar, 20);
        p[3].Value = this._phno;

        p[4] = new SqlParameter("@homephno", SqlDbType.VarChar, 20);
        p[4].Value = this._homephno;

        p[5] = new SqlParameter("@emailid", SqlDbType.VarChar, 50);
        p[5].Value = this._emailid;

        p[6] = new SqlParameter("@peraddress", SqlDbType.VarChar, 250);
        p[6].Value = this.Peraddress;

        p[7] = new SqlParameter("@preaddress", SqlDbType.VarChar, 250);
        p[7].Value = this._preaddress;
        p[8] = new SqlParameter("@empid", SqlDbType.VarChar, 10);
        p[8].Value = this._empid;

        SqlHelper.ExecuteNonQuery(Connection.Con, CommandType.StoredProcedure, "SpUpdateEmpOwnDetails", p);
    }
    public static DataRow  getdata(string empid)
    {
       return (DataRow) SqlHelper.ExecuteDataset(Connection.Con, CommandType.Text, "select *from empowndetails where empid='" + empid + "'").Tables[0].Rows[0];
    }
}
