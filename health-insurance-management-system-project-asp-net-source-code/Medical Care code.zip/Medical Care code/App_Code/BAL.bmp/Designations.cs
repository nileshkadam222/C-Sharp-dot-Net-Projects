using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for Designations
/// </summary>
public class Designations
{
	public Designations()
	{
		
	}
    int _DesiId;
    string _DesiName;
    string _DesiDescription;
    public int DesiId
    {
        get { return _DesiId; }
        set { _DesiId = value; }
    }
    public string DesiName
    {
        get { return _DesiName; }
        set { _DesiName = value; }
     }
    public string DesiDescription
    {
        get { return _DesiDescription; }
        set { _DesiDescription = value; }

    }
    public void InsertDesignation()
    {
        SqlParameter[] p = new SqlParameter[3];
        p[0] = new SqlParameter("@desiid", SqlDbType.Int);
        p[0].Value = this._DesiId;
        p[1] = new SqlParameter("@desiname", SqlDbType.VarChar, 50);
        p[1].Value = this._DesiName;
        p[2] = new SqlParameter("@desidesc", SqlDbType.VarChar, 50);
        p[2].Value = this._DesiDescription;
        SqlHelper.ExecuteNonQuery(Connection.Con, CommandType.StoredProcedure , "SpinsertDesignation", p);
    }
    public static DataSet Getdesignations()
    {
        return SqlHelper.ExecuteDataset(Connection.Con, CommandType.Text , "select *from designation");
    }
    public static DataSet Getpolicyonemploye(string desi)
    {
        SqlParameter p=new SqlParameter("@desi",SqlDbType.VarChar,50);
        p.Value=desi;
        return SqlHelper.ExecuteDataset(Connection.Con, CommandType.StoredProcedure, "Spgetemloyee", p);
    }

}
