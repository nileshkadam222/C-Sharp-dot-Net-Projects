﻿namespace SangliTradingCompany
{
    partial class TodaysAttendence
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.lastname_comb = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cbname = new System.Windows.Forms.ComboBox();
            this.cbid = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dtpdate = new System.Windows.Forms.DateTimePicker();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbltime = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.rbnyes = new System.Windows.Forms.RadioButton();
            this.rbnno = new System.Windows.Forms.RadioButton();
            this.gbstatus = new System.Windows.Forms.GroupBox();
            this.rbnon = new System.Windows.Forms.RadioButton();
            this.rbnouttime = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btndelete = new System.Windows.Forms.Button();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btnsave = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Cancel_btn = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.gbstatus.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.Transparent;
            this.groupBox4.Controls.Add(this.lastname_comb);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.cbname);
            this.groupBox4.Controls.Add(this.cbid);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.dtpdate);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(28, 27);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(922, 134);
            this.groupBox4.TabIndex = 46;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Employee Detail";
            // 
            // lastname_comb
            // 
            this.lastname_comb.FormattingEnabled = true;
            this.lastname_comb.Location = new System.Drawing.Point(151, 99);
            this.lastname_comb.Name = "lastname_comb";
            this.lastname_comb.Size = new System.Drawing.Size(121, 24);
            this.lastname_comb.TabIndex = 41;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 99);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 17);
            this.label5.TabIndex = 40;
            this.label5.Text = "Last Name";
            // 
            // cbname
            // 
            this.cbname.FormattingEnabled = true;
            this.cbname.Location = new System.Drawing.Point(151, 61);
            this.cbname.Name = "cbname";
            this.cbname.Size = new System.Drawing.Size(121, 24);
            this.cbname.TabIndex = 39;
            // 
            // cbid
            // 
            this.cbid.FormattingEnabled = true;
            this.cbid.Location = new System.Drawing.Point(151, 24);
            this.cbid.Name = "cbid";
            this.cbid.Size = new System.Drawing.Size(121, 24);
            this.cbid.TabIndex = 38;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 17);
            this.label1.TabIndex = 31;
            this.label1.Text = "ID :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 17);
            this.label2.TabIndex = 32;
            this.label2.Text = "Name :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(582, 61);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 17);
            this.label3.TabIndex = 34;
            this.label3.Text = "Date :";
            // 
            // dtpdate
            // 
            this.dtpdate.Location = new System.Drawing.Point(664, 54);
            this.dtpdate.Name = "dtpdate";
            this.dtpdate.Size = new System.Drawing.Size(199, 23);
            this.dtpdate.TabIndex = 37;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.lbltime);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.groupBox5);
            this.groupBox1.Controls.Add(this.gbstatus);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(28, 181);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(922, 144);
            this.groupBox1.TabIndex = 47;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Attendence Detail";
            // 
            // lbltime
            // 
            this.lbltime.AutoSize = true;
            this.lbltime.Location = new System.Drawing.Point(825, 71);
            this.lbltime.Name = "lbltime";
            this.lbltime.Size = new System.Drawing.Size(0, 17);
            this.lbltime.TabIndex = 47;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(766, 73);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 17);
            this.label4.TabIndex = 46;
            this.label4.Text = "Time :";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.rbnyes);
            this.groupBox5.Controls.Add(this.rbnno);
            this.groupBox5.Location = new System.Drawing.Point(57, 39);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(327, 69);
            this.groupBox5.TabIndex = 44;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Present";
            // 
            // rbnyes
            // 
            this.rbnyes.AutoSize = true;
            this.rbnyes.Location = new System.Drawing.Point(31, 33);
            this.rbnyes.Name = "rbnyes";
            this.rbnyes.Size = new System.Drawing.Size(50, 21);
            this.rbnyes.TabIndex = 38;
            this.rbnyes.TabStop = true;
            this.rbnyes.Text = "Yes";
            this.rbnyes.UseVisualStyleBackColor = true;
            this.rbnyes.CheckedChanged += new System.EventHandler(this.rbnyes_CheckedChanged_1);
            // 
            // rbnno
            // 
            this.rbnno.AutoSize = true;
            this.rbnno.Location = new System.Drawing.Point(209, 33);
            this.rbnno.Name = "rbnno";
            this.rbnno.Size = new System.Drawing.Size(44, 21);
            this.rbnno.TabIndex = 39;
            this.rbnno.TabStop = true;
            this.rbnno.Text = "No";
            this.rbnno.UseVisualStyleBackColor = true;
            this.rbnno.CheckedChanged += new System.EventHandler(this.rbnno_CheckedChanged_1);
            // 
            // gbstatus
            // 
            this.gbstatus.Controls.Add(this.rbnon);
            this.gbstatus.Controls.Add(this.rbnouttime);
            this.gbstatus.Location = new System.Drawing.Point(422, 39);
            this.gbstatus.Name = "gbstatus";
            this.gbstatus.Size = new System.Drawing.Size(328, 69);
            this.gbstatus.TabIndex = 43;
            this.gbstatus.TabStop = false;
            this.gbstatus.Text = "gpstatus";
            // 
            // rbnon
            // 
            this.rbnon.AutoSize = true;
            this.rbnon.Location = new System.Drawing.Point(32, 32);
            this.rbnon.Name = "rbnon";
            this.rbnon.Size = new System.Drawing.Size(76, 21);
            this.rbnon.TabIndex = 40;
            this.rbnon.TabStop = true;
            this.rbnon.Text = "OnTime";
            this.rbnon.UseVisualStyleBackColor = true;
            // 
            // rbnouttime
            // 
            this.rbnouttime.AutoSize = true;
            this.rbnouttime.Location = new System.Drawing.Point(209, 32);
            this.rbnouttime.Name = "rbnouttime";
            this.rbnouttime.Size = new System.Drawing.Size(80, 21);
            this.rbnouttime.TabIndex = 41;
            this.rbnouttime.TabStop = true;
            this.rbnouttime.Text = "OutTime";
            this.rbnouttime.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Transparent;
            this.groupBox3.Controls.Add(this.btndelete);
            this.groupBox3.Controls.Add(this.btnupdate);
            this.groupBox3.Controls.Add(this.btnsave);
            this.groupBox3.Location = new System.Drawing.Point(424, 436);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(467, 74);
            this.groupBox3.TabIndex = 48;
            this.groupBox3.TabStop = false;
            // 
            // btndelete
            // 
            this.btndelete.Location = new System.Drawing.Point(296, 28);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(75, 23);
            this.btndelete.TabIndex = 3;
            this.btndelete.Text = "Delete";
            this.btndelete.UseVisualStyleBackColor = true;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.Location = new System.Drawing.Point(155, 28);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(75, 23);
            this.btnupdate.TabIndex = 2;
            this.btnupdate.Text = "Update";
            this.btnupdate.UseVisualStyleBackColor = true;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // btnsave
            // 
            this.btnsave.Location = new System.Drawing.Point(15, 28);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(75, 23);
            this.btnsave.TabIndex = 1;
            this.btnsave.Text = "Save";
            this.btnsave.UseVisualStyleBackColor = true;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.Cancel_btn);
            this.groupBox2.Location = new System.Drawing.Point(557, 544);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(248, 58);
            this.groupBox2.TabIndex = 49;
            this.groupBox2.TabStop = false;
            // 
            // Cancel_btn
            // 
            this.Cancel_btn.Location = new System.Drawing.Point(83, 19);
            this.Cancel_btn.Name = "Cancel_btn";
            this.Cancel_btn.Size = new System.Drawing.Size(75, 23);
            this.Cancel_btn.TabIndex = 0;
            this.Cancel_btn.Text = "Cancel";
            this.Cancel_btn.UseVisualStyleBackColor = true;
            this.Cancel_btn.Click += new System.EventHandler(this.Cancel_btn_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::SangliTradingCompany.Properties.Resources.canstock11308192;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(1009, 81);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(271, 270);
            this.pictureBox1.TabIndex = 50;
            this.pictureBox1.TabStop = false;
            // 
            // TodaysAttendence
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1315, 651);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox4);
            this.Name = "TodaysAttendence";
            this.Text = "TodaysAttendence";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.TodaysAttendence_Load);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.gbstatus.ResumeLayout(false);
            this.gbstatus.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ComboBox cbname;
        private System.Windows.Forms.ComboBox cbid;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dtpdate;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lbltime;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RadioButton rbnyes;
        private System.Windows.Forms.RadioButton rbnno;
        private System.Windows.Forms.GroupBox gbstatus;
        private System.Windows.Forms.RadioButton rbnon;
        private System.Windows.Forms.RadioButton rbnouttime;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.ComboBox lastname_comb;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button Cancel_btn;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}