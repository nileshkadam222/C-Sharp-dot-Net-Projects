﻿namespace SangliTradingCompany
{
    partial class RegisterEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Dob_datetimepicker = new System.Windows.Forms.DateTimePicker();
            this.age_txt = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Femaleradio_btn = new System.Windows.Forms.RadioButton();
            this.maleradio_btn = new System.Windows.Forms.RadioButton();
            this.mobno_txt = new System.Windows.Forms.TextBox();
            this.lastname_txt = new System.Windows.Forms.TextBox();
            this.Fathername_txt = new System.Windows.Forms.TextBox();
            this.empfirstname_txt = new System.Windows.Forms.TextBox();
            this.Add_txt = new System.Windows.Forms.TextBox();
            this.empid_txt = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Regno_txt = new System.Windows.Forms.TextBox();
            this.Groupno_txt = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.DojdateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.Designationcombo_box = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.Cancel_btn = new System.Windows.Forms.Button();
            this.Newentry_btn = new System.Windows.Forms.Button();
            this.Save_btn = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.Dob_datetimepicker);
            this.groupBox1.Controls.Add(this.age_txt);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.mobno_txt);
            this.groupBox1.Controls.Add(this.lastname_txt);
            this.groupBox1.Controls.Add(this.Fathername_txt);
            this.groupBox1.Controls.Add(this.empfirstname_txt);
            this.groupBox1.Controls.Add(this.Add_txt);
            this.groupBox1.Controls.Add(this.empid_txt);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(205, 46);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(388, 389);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Personal Details";
            // 
            // Dob_datetimepicker
            // 
            this.Dob_datetimepicker.Location = new System.Drawing.Point(168, 222);
            this.Dob_datetimepicker.MaxDate = new System.DateTime(2015, 1, 5, 0, 0, 0, 0);
            this.Dob_datetimepicker.Name = "Dob_datetimepicker";
            this.Dob_datetimepicker.Size = new System.Drawing.Size(200, 23);
            this.Dob_datetimepicker.TabIndex = 12;
            this.Dob_datetimepicker.Value = new System.DateTime(2015, 1, 5, 0, 0, 0, 0);
            // 
            // age_txt
            // 
            this.age_txt.Location = new System.Drawing.Point(168, 260);
            this.age_txt.Name = "age_txt";
            this.age_txt.Size = new System.Drawing.Size(100, 23);
            this.age_txt.TabIndex = 11;
            this.age_txt.TextChanged += new System.EventHandler(this.age_txt_TextChanged);
            this.age_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.age_txt_KeyPress);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Femaleradio_btn);
            this.groupBox2.Controls.Add(this.maleradio_btn);
            this.groupBox2.Location = new System.Drawing.Point(168, 158);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(212, 47);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            // 
            // Femaleradio_btn
            // 
            this.Femaleradio_btn.AutoSize = true;
            this.Femaleradio_btn.Location = new System.Drawing.Point(116, 19);
            this.Femaleradio_btn.Name = "Femaleradio_btn";
            this.Femaleradio_btn.Size = new System.Drawing.Size(72, 21);
            this.Femaleradio_btn.TabIndex = 13;
            this.Femaleradio_btn.TabStop = true;
            this.Femaleradio_btn.Text = "Female";
            this.Femaleradio_btn.UseVisualStyleBackColor = true;
            // 
            // maleradio_btn
            // 
            this.maleradio_btn.AutoSize = true;
            this.maleradio_btn.Location = new System.Drawing.Point(6, 19);
            this.maleradio_btn.Name = "maleradio_btn";
            this.maleradio_btn.Size = new System.Drawing.Size(56, 21);
            this.maleradio_btn.TabIndex = 12;
            this.maleradio_btn.TabStop = true;
            this.maleradio_btn.Text = "Male";
            this.maleradio_btn.UseVisualStyleBackColor = true;
            // 
            // mobno_txt
            // 
            this.mobno_txt.Location = new System.Drawing.Point(168, 347);
            this.mobno_txt.MaxLength = 10;
            this.mobno_txt.Name = "mobno_txt";
            this.mobno_txt.Size = new System.Drawing.Size(158, 23);
            this.mobno_txt.TabIndex = 9;
            this.mobno_txt.TextChanged += new System.EventHandler(this.mobno_txt_TextChanged);
            this.mobno_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mobno_txt_KeyPress);
            // 
            // lastname_txt
            // 
            this.lastname_txt.Location = new System.Drawing.Point(168, 135);
            this.lastname_txt.Name = "lastname_txt";
            this.lastname_txt.Size = new System.Drawing.Size(114, 23);
            this.lastname_txt.TabIndex = 9;
            this.lastname_txt.TextChanged += new System.EventHandler(this.validTextChar);
            // 
            // Fathername_txt
            // 
            this.Fathername_txt.Location = new System.Drawing.Point(168, 98);
            this.Fathername_txt.Name = "Fathername_txt";
            this.Fathername_txt.Size = new System.Drawing.Size(114, 23);
            this.Fathername_txt.TabIndex = 8;
            this.Fathername_txt.TextChanged += new System.EventHandler(this.validTextChar);
            // 
            // empfirstname_txt
            // 
            this.empfirstname_txt.Location = new System.Drawing.Point(168, 59);
            this.empfirstname_txt.Name = "empfirstname_txt";
            this.empfirstname_txt.Size = new System.Drawing.Size(114, 23);
            this.empfirstname_txt.TabIndex = 7;
            this.empfirstname_txt.TextChanged += new System.EventHandler(this.validTextChar);
            // 
            // Add_txt
            // 
            this.Add_txt.Location = new System.Drawing.Point(168, 294);
            this.Add_txt.Multiline = true;
            this.Add_txt.Name = "Add_txt";
            this.Add_txt.Size = new System.Drawing.Size(176, 35);
            this.Add_txt.TabIndex = 7;
            // 
            // empid_txt
            // 
            this.empid_txt.Location = new System.Drawing.Point(168, 26);
            this.empid_txt.Name = "empid_txt";
            this.empid_txt.Size = new System.Drawing.Size(114, 23);
            this.empid_txt.TabIndex = 6;
            this.empid_txt.TextChanged += new System.EventHandler(this.validTextInteger);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(25, 354);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(103, 17);
            this.label12.TabIndex = 4;
            this.label12.Text = "Mobile Number";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(25, 267);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(33, 17);
            this.label7.TabIndex = 5;
            this.label7.Text = "Age";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(25, 229);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 17);
            this.label6.TabIndex = 4;
            this.label6.Text = "Date Of Birth";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(25, 175);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 17);
            this.label5.TabIndex = 1;
            this.label5.Text = "Gender";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, 132);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Last Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 98);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Father\'s Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(134, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Emloyee First Name";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(25, 297);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 17);
            this.label8.TabIndex = 0;
            this.label8.Text = "Address";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Employee ID";
            // 
            // Regno_txt
            // 
            this.Regno_txt.Location = new System.Drawing.Point(161, 152);
            this.Regno_txt.Name = "Regno_txt";
            this.Regno_txt.Size = new System.Drawing.Size(100, 23);
            this.Regno_txt.TabIndex = 19;
            this.Regno_txt.TextChanged += new System.EventHandler(this.validTextInteger);
            // 
            // Groupno_txt
            // 
            this.Groupno_txt.Location = new System.Drawing.Point(161, 200);
            this.Groupno_txt.Name = "Groupno_txt";
            this.Groupno_txt.Size = new System.Drawing.Size(100, 23);
            this.Groupno_txt.TabIndex = 20;
            this.Groupno_txt.TextChanged += new System.EventHandler(this.validTextInteger);
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.Transparent;
            this.groupBox4.Controls.Add(this.Groupno_txt);
            this.groupBox4.Controls.Add(this.Regno_txt);
            this.groupBox4.Controls.Add(this.DojdateTimePicker);
            this.groupBox4.Controls.Add(this.Designationcombo_box);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(827, 87);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(339, 331);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Employee Department Detail";
            // 
            // DojdateTimePicker
            // 
            this.DojdateTimePicker.Location = new System.Drawing.Point(133, 98);
            this.DojdateTimePicker.Name = "DojdateTimePicker";
            this.DojdateTimePicker.Size = new System.Drawing.Size(200, 23);
            this.DojdateTimePicker.TabIndex = 18;
            // 
            // Designationcombo_box
            // 
            this.Designationcombo_box.FormattingEnabled = true;
            this.Designationcombo_box.Items.AddRange(new object[] {
            "Manager",
            "Accountant",
            "Worker"});
            this.Designationcombo_box.Location = new System.Drawing.Point(161, 41);
            this.Designationcombo_box.Name = "Designationcombo_box";
            this.Designationcombo_box.Size = new System.Drawing.Size(121, 24);
            this.Designationcombo_box.TabIndex = 17;
            this.Designationcombo_box.SelectedIndexChanged += new System.EventHandler(this.Designationcombo_box_SelectedIndexChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(17, 215);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(102, 17);
            this.label17.TabIndex = 16;
            this.label17.Text = "Group Number";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(17, 158);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(138, 17);
            this.label16.TabIndex = 15;
            this.label16.Text = "Registration Number";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(17, 105);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(106, 17);
            this.label15.TabIndex = 14;
            this.label15.Text = "Date Of Joining";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(17, 41);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(83, 17);
            this.label10.TabIndex = 13;
            this.label10.Text = "Designation";
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.Transparent;
            this.groupBox5.Controls.Add(this.Cancel_btn);
            this.groupBox5.Controls.Add(this.Newentry_btn);
            this.groupBox5.Controls.Add(this.Save_btn);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(454, 466);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(473, 84);
            this.groupBox5.TabIndex = 6;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Add Employee Detail";
            // 
            // Cancel_btn
            // 
            this.Cancel_btn.Location = new System.Drawing.Point(392, 35);
            this.Cancel_btn.Name = "Cancel_btn";
            this.Cancel_btn.Size = new System.Drawing.Size(75, 23);
            this.Cancel_btn.TabIndex = 2;
            this.Cancel_btn.Text = "Cancel";
            this.Cancel_btn.UseVisualStyleBackColor = true;
            this.Cancel_btn.Click += new System.EventHandler(this.Cancel_btn_Click);
            // 
            // Newentry_btn
            // 
            this.Newentry_btn.Location = new System.Drawing.Point(225, 35);
            this.Newentry_btn.Name = "Newentry_btn";
            this.Newentry_btn.Size = new System.Drawing.Size(88, 23);
            this.Newentry_btn.TabIndex = 1;
            this.Newentry_btn.Text = "New Entry";
            this.Newentry_btn.UseVisualStyleBackColor = true;
            this.Newentry_btn.Click += new System.EventHandler(this.Newentry_btn_Click);
            // 
            // Save_btn
            // 
            this.Save_btn.Location = new System.Drawing.Point(39, 35);
            this.Save_btn.Name = "Save_btn";
            this.Save_btn.Size = new System.Drawing.Size(75, 23);
            this.Save_btn.TabIndex = 0;
            this.Save_btn.Text = "Save";
            this.Save_btn.UseVisualStyleBackColor = true;
            this.Save_btn.Click += new System.EventHandler(this.Save_btn_Click);
            // 
            // RegisterEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1322, 654);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox5);
            this.Name = "RegisterEmployee";
            this.Text = "RegisterEmployee";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.RegisterEmployee_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DateTimePicker Dob_datetimepicker;
        private System.Windows.Forms.TextBox age_txt;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton Femaleradio_btn;
        private System.Windows.Forms.RadioButton maleradio_btn;
        private System.Windows.Forms.TextBox lastname_txt;
        private System.Windows.Forms.TextBox Fathername_txt;
        private System.Windows.Forms.TextBox empfirstname_txt;
        private System.Windows.Forms.TextBox empid_txt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Regno_txt;
        private System.Windows.Forms.TextBox mobno_txt;
        private System.Windows.Forms.TextBox Groupno_txt;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.DateTimePicker DojdateTimePicker;
        private System.Windows.Forms.ComboBox Designationcombo_box;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button Cancel_btn;
        private System.Windows.Forms.Button Newentry_btn;
        private System.Windows.Forms.Button Save_btn;
        private System.Windows.Forms.TextBox Add_txt;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label8;
    }
}