﻿namespace SangliTradingCompany
{
    partial class AddDryFruit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.weight_txt = new System.Windows.Forms.TextBox();
            this.price_txt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.serno_txt = new System.Windows.Forms.TextBox();
            this.Box_txt = new System.Windows.Forms.TextBox();
            this.Proname_cmbo = new System.Windows.Forms.ComboBox();
            this.quan_txt = new System.Windows.Forms.TextBox();
            this.proid_txt = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Newentry_btn = new System.Windows.Forms.Button();
            this.Save_btn = new System.Windows.Forms.Button();
            this.cancel_btn = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.Transparent;
            this.groupBox4.Controls.Add(this.dateTimePicker2);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.dateTimePicker1);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.weight_txt);
            this.groupBox4.Controls.Add(this.price_txt);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.serno_txt);
            this.groupBox4.Controls.Add(this.Box_txt);
            this.groupBox4.Controls.Add(this.Proname_cmbo);
            this.groupBox4.Controls.Add(this.quan_txt);
            this.groupBox4.Controls.Add(this.proid_txt);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(346, 51);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(475, 408);
            this.groupBox4.TabIndex = 29;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Product Detail";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(258, 345);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(200, 23);
            this.dateTimePicker2.TabIndex = 16;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(382, 251);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(36, 17);
            this.label10.TabIndex = 21;
            this.label10.Text = "/-RS";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(258, 297);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 23);
            this.dateTimePicker1.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(74, 26);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(68, 17);
            this.label8.TabIndex = 17;
            this.label8.Text = "Serial no.";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(74, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Product ID";
            // 
            // weight_txt
            // 
            this.weight_txt.Location = new System.Drawing.Point(258, 216);
            this.weight_txt.Name = "weight_txt";
            this.weight_txt.Size = new System.Drawing.Size(100, 23);
            this.weight_txt.TabIndex = 20;
            this.weight_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // price_txt
            // 
            this.price_txt.Location = new System.Drawing.Point(258, 251);
            this.price_txt.Name = "price_txt";
            this.price_txt.Size = new System.Drawing.Size(100, 23);
            this.price_txt.TabIndex = 14;
            this.price_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(73, 102);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Product Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(74, 143);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Quantity";
            // 
            // serno_txt
            // 
            this.serno_txt.Location = new System.Drawing.Point(258, 26);
            this.serno_txt.Name = "serno_txt";
            this.serno_txt.Size = new System.Drawing.Size(100, 23);
            this.serno_txt.TabIndex = 18;
            this.serno_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.serno_txt_KeyPress);
            // 
            // Box_txt
            // 
            this.Box_txt.Location = new System.Drawing.Point(258, 178);
            this.Box_txt.Name = "Box_txt";
            this.Box_txt.Size = new System.Drawing.Size(100, 23);
            this.Box_txt.TabIndex = 13;
            this.Box_txt.TextChanged += new System.EventHandler(this.validTextInteger);
            // 
            // Proname_cmbo
            // 
            this.Proname_cmbo.FormattingEnabled = true;
            this.Proname_cmbo.Items.AddRange(new object[] {
            "Badam",
            "Kaju",
            "Khajoor",
            "Pista",
            "Kishmish",
            "Akhrot"});
            this.Proname_cmbo.Location = new System.Drawing.Point(258, 102);
            this.Proname_cmbo.Name = "Proname_cmbo";
            this.Proname_cmbo.Size = new System.Drawing.Size(144, 24);
            this.Proname_cmbo.TabIndex = 11;
            this.Proname_cmbo.SelectedIndexChanged += new System.EventHandler(this.Proname_cmbo_SelectedIndexChanged_1);
            // 
            // quan_txt
            // 
            this.quan_txt.Location = new System.Drawing.Point(258, 143);
            this.quan_txt.Name = "quan_txt";
            this.quan_txt.Size = new System.Drawing.Size(100, 23);
            this.quan_txt.TabIndex = 12;
            this.quan_txt.TextChanged += new System.EventHandler(this.validTextInteger);
            // 
            // proid_txt
            // 
            this.proid_txt.Location = new System.Drawing.Point(258, 61);
            this.proid_txt.Name = "proid_txt";
            this.proid_txt.Size = new System.Drawing.Size(100, 23);
            this.proid_txt.TabIndex = 10;
            this.proid_txt.TextChanged += new System.EventHandler(this.validTextInteger);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(74, 352);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 17);
            this.label6.TabIndex = 5;
            this.label6.Text = "Expired Date";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(74, 178);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Boxes";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(74, 216);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 17);
            this.label9.TabIndex = 19;
            this.label9.Text = "Weight";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(74, 258);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(40, 17);
            this.label7.TabIndex = 6;
            this.label7.Text = "Price";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(74, 303);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "Order Date";
            // 
            // Newentry_btn
            // 
            this.Newentry_btn.Location = new System.Drawing.Point(17, 16);
            this.Newentry_btn.Name = "Newentry_btn";
            this.Newentry_btn.Size = new System.Drawing.Size(103, 23);
            this.Newentry_btn.TabIndex = 10;
            this.Newentry_btn.Text = "New Entry";
            this.Newentry_btn.UseVisualStyleBackColor = true;
            this.Newentry_btn.Click += new System.EventHandler(this.Newentry_btn_Click);
            // 
            // Save_btn
            // 
            this.Save_btn.Location = new System.Drawing.Point(198, 13);
            this.Save_btn.Name = "Save_btn";
            this.Save_btn.Size = new System.Drawing.Size(75, 26);
            this.Save_btn.TabIndex = 7;
            this.Save_btn.Text = "Save";
            this.Save_btn.UseVisualStyleBackColor = true;
            this.Save_btn.Click += new System.EventHandler(this.Save_btn_Click);
            // 
            // cancel_btn
            // 
            this.cancel_btn.Location = new System.Drawing.Point(363, 13);
            this.cancel_btn.Name = "cancel_btn";
            this.cancel_btn.Size = new System.Drawing.Size(75, 26);
            this.cancel_btn.TabIndex = 9;
            this.cancel_btn.Text = "Cancel";
            this.cancel_btn.UseVisualStyleBackColor = true;
            this.cancel_btn.Click += new System.EventHandler(this.cancel_btn_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.Controls.Add(this.Newentry_btn);
            this.panel2.Controls.Add(this.Save_btn);
            this.panel2.Controls.Add(this.cancel_btn);
            this.panel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel2.Location = new System.Drawing.Point(346, 514);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(475, 52);
            this.panel2.TabIndex = 28;
            // 
            // AddDryFruit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BackgroundImage = global::SangliTradingCompany.Properties.Resources.fruit_and_nut_basket_2_pound;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1347, 731);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.panel2);
            this.Name = "AddDryFruit";
            this.Text = "AddDryFruit";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.AddDryFruit_Load);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox weight_txt;
        private System.Windows.Forms.TextBox price_txt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox serno_txt;
        private System.Windows.Forms.TextBox Box_txt;
        private System.Windows.Forms.ComboBox Proname_cmbo;
        private System.Windows.Forms.TextBox quan_txt;
        private System.Windows.Forms.TextBox proid_txt;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button Newentry_btn;
        private System.Windows.Forms.Button Save_btn;
        private System.Windows.Forms.Button cancel_btn;
        private System.Windows.Forms.Panel panel2;
    }
}