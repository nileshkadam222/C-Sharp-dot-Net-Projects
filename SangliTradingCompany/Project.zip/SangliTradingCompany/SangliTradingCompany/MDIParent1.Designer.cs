﻿namespace SangliTradingCompany
{
    partial class MDIParent1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.pRODUCTDETAILSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dRYFRUITDETAILSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addDryFruitDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchDryFruitDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateDryFruitDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewDryFruitDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewDryFruitDetailsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.spicesDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addSpicesDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchSpicesDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateSpicesDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteSpicesRecordsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewSpicesDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.RegistrationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.employeeDetailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.customerregToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SupplierregToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EmploeeDETAILToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.modempToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.attenToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.todaysAttendenceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.attendenceRecordsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salaryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.recordsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.customerDETAILSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.modifiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.recordsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.supplierDETAILSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.modifyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewOfRecordsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ordersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.venderToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.dryfruitOrderDetailsToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.spicesOrderDetailsToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.customerToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.dryFruitOrderDetailsToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.spicesOrderDetailsToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.billToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rEPORTSToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.dryFruitReportToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.spicesReportToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.employeeReportToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.emploeeSalaryReportToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.employeeAttendenceReportToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.customerReportToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.supplierReportsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.billReportToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.menuStrip.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pRODUCTDETAILSToolStripMenuItem,
            this.RegistrationToolStripMenuItem,
            this.EmploeeDETAILToolStripMenuItem,
            this.customerDETAILSToolStripMenuItem,
            this.supplierDETAILSToolStripMenuItem,
            this.ordersToolStripMenuItem,
            this.billToolStripMenuItem,
            this.rEPORTSToolStripMenuItem1});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(1275, 29);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            // 
            // pRODUCTDETAILSToolStripMenuItem
            // 
            this.pRODUCTDETAILSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dRYFRUITDETAILSToolStripMenuItem,
            this.spicesDetailsToolStripMenuItem});
            this.pRODUCTDETAILSToolStripMenuItem.Name = "pRODUCTDETAILSToolStripMenuItem";
            this.pRODUCTDETAILSToolStripMenuItem.Size = new System.Drawing.Size(155, 25);
            this.pRODUCTDETAILSToolStripMenuItem.Text = "PRODUCT DETAILS";
            this.pRODUCTDETAILSToolStripMenuItem.Click += new System.EventHandler(this.pRODUCTDETAILSToolStripMenuItem_Click);
            // 
            // dRYFRUITDETAILSToolStripMenuItem
            // 
            this.dRYFRUITDETAILSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addDryFruitDetailsToolStripMenuItem,
            this.searchDryFruitDetailsToolStripMenuItem,
            this.updateDryFruitDetailsToolStripMenuItem,
            this.viewDryFruitDetailsToolStripMenuItem,
            this.viewDryFruitDetailsToolStripMenuItem1});
            this.dRYFRUITDETAILSToolStripMenuItem.Name = "dRYFRUITDETAILSToolStripMenuItem";
            this.dRYFRUITDETAILSToolStripMenuItem.Size = new System.Drawing.Size(137, 26);
            this.dRYFRUITDETAILSToolStripMenuItem.Text = "DryFruit";
            // 
            // addDryFruitDetailsToolStripMenuItem
            // 
            this.addDryFruitDetailsToolStripMenuItem.Name = "addDryFruitDetailsToolStripMenuItem";
            this.addDryFruitDetailsToolStripMenuItem.Size = new System.Drawing.Size(136, 26);
            this.addDryFruitDetailsToolStripMenuItem.Text = "Add ";
            this.addDryFruitDetailsToolStripMenuItem.Click += new System.EventHandler(this.addDryFruitDetailsToolStripMenuItem_Click);
            // 
            // searchDryFruitDetailsToolStripMenuItem
            // 
            this.searchDryFruitDetailsToolStripMenuItem.Name = "searchDryFruitDetailsToolStripMenuItem";
            this.searchDryFruitDetailsToolStripMenuItem.Size = new System.Drawing.Size(136, 26);
            this.searchDryFruitDetailsToolStripMenuItem.Text = "Search ";
            this.searchDryFruitDetailsToolStripMenuItem.Click += new System.EventHandler(this.searchDryFruitDetailsToolStripMenuItem_Click);
            // 
            // updateDryFruitDetailsToolStripMenuItem
            // 
            this.updateDryFruitDetailsToolStripMenuItem.Name = "updateDryFruitDetailsToolStripMenuItem";
            this.updateDryFruitDetailsToolStripMenuItem.Size = new System.Drawing.Size(136, 26);
            this.updateDryFruitDetailsToolStripMenuItem.Text = "Update";
            this.updateDryFruitDetailsToolStripMenuItem.Click += new System.EventHandler(this.updateDryFruitDetailsToolStripMenuItem_Click);
            // 
            // viewDryFruitDetailsToolStripMenuItem
            // 
            this.viewDryFruitDetailsToolStripMenuItem.Name = "viewDryFruitDetailsToolStripMenuItem";
            this.viewDryFruitDetailsToolStripMenuItem.Size = new System.Drawing.Size(136, 26);
            this.viewDryFruitDetailsToolStripMenuItem.Text = "Delete";
            this.viewDryFruitDetailsToolStripMenuItem.Click += new System.EventHandler(this.viewDryFruitDetailsToolStripMenuItem_Click);
            // 
            // viewDryFruitDetailsToolStripMenuItem1
            // 
            this.viewDryFruitDetailsToolStripMenuItem1.Name = "viewDryFruitDetailsToolStripMenuItem1";
            this.viewDryFruitDetailsToolStripMenuItem1.Size = new System.Drawing.Size(136, 26);
            this.viewDryFruitDetailsToolStripMenuItem1.Text = "Records";
            this.viewDryFruitDetailsToolStripMenuItem1.Click += new System.EventHandler(this.viewDryFruitDetailsToolStripMenuItem1_Click);
            // 
            // spicesDetailsToolStripMenuItem
            // 
            this.spicesDetailsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addSpicesDetailsToolStripMenuItem,
            this.searchSpicesDetailsToolStripMenuItem,
            this.updateSpicesDetailsToolStripMenuItem,
            this.deleteSpicesRecordsToolStripMenuItem,
            this.viewSpicesDetailsToolStripMenuItem});
            this.spicesDetailsToolStripMenuItem.Name = "spicesDetailsToolStripMenuItem";
            this.spicesDetailsToolStripMenuItem.Size = new System.Drawing.Size(137, 26);
            this.spicesDetailsToolStripMenuItem.Text = "Spices ";
            // 
            // addSpicesDetailsToolStripMenuItem
            // 
            this.addSpicesDetailsToolStripMenuItem.Name = "addSpicesDetailsToolStripMenuItem";
            this.addSpicesDetailsToolStripMenuItem.Size = new System.Drawing.Size(136, 26);
            this.addSpicesDetailsToolStripMenuItem.Text = "Add ";
            this.addSpicesDetailsToolStripMenuItem.Click += new System.EventHandler(this.addSpicesDetailsToolStripMenuItem_Click);
            // 
            // searchSpicesDetailsToolStripMenuItem
            // 
            this.searchSpicesDetailsToolStripMenuItem.Name = "searchSpicesDetailsToolStripMenuItem";
            this.searchSpicesDetailsToolStripMenuItem.Size = new System.Drawing.Size(136, 26);
            this.searchSpicesDetailsToolStripMenuItem.Text = "Search ";
            this.searchSpicesDetailsToolStripMenuItem.Click += new System.EventHandler(this.searchSpicesDetailsToolStripMenuItem_Click);
            // 
            // updateSpicesDetailsToolStripMenuItem
            // 
            this.updateSpicesDetailsToolStripMenuItem.Name = "updateSpicesDetailsToolStripMenuItem";
            this.updateSpicesDetailsToolStripMenuItem.Size = new System.Drawing.Size(136, 26);
            this.updateSpicesDetailsToolStripMenuItem.Text = "Update ";
            this.updateSpicesDetailsToolStripMenuItem.Click += new System.EventHandler(this.updateSpicesDetailsToolStripMenuItem_Click);
            // 
            // deleteSpicesRecordsToolStripMenuItem
            // 
            this.deleteSpicesRecordsToolStripMenuItem.Name = "deleteSpicesRecordsToolStripMenuItem";
            this.deleteSpicesRecordsToolStripMenuItem.Size = new System.Drawing.Size(136, 26);
            this.deleteSpicesRecordsToolStripMenuItem.Text = "Delete ";
            this.deleteSpicesRecordsToolStripMenuItem.Click += new System.EventHandler(this.deleteSpicesRecordsToolStripMenuItem_Click);
            // 
            // viewSpicesDetailsToolStripMenuItem
            // 
            this.viewSpicesDetailsToolStripMenuItem.Name = "viewSpicesDetailsToolStripMenuItem";
            this.viewSpicesDetailsToolStripMenuItem.Size = new System.Drawing.Size(136, 26);
            this.viewSpicesDetailsToolStripMenuItem.Text = "Records";
            this.viewSpicesDetailsToolStripMenuItem.Click += new System.EventHandler(this.viewSpicesDetailsToolStripMenuItem_Click);
            // 
            // RegistrationToolStripMenuItem
            // 
            this.RegistrationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.employeeDetailToolStripMenuItem,
            this.customerregToolStripMenuItem,
            this.SupplierregToolStripMenuItem});
            this.RegistrationToolStripMenuItem.Name = "RegistrationToolStripMenuItem";
            this.RegistrationToolStripMenuItem.Size = new System.Drawing.Size(90, 25);
            this.RegistrationToolStripMenuItem.Text = "REGISTER";
            // 
            // employeeDetailToolStripMenuItem
            // 
            this.employeeDetailToolStripMenuItem.Name = "employeeDetailToolStripMenuItem";
            this.employeeDetailToolStripMenuItem.Size = new System.Drawing.Size(152, 26);
            this.employeeDetailToolStripMenuItem.Text = "Employee ";
            this.employeeDetailToolStripMenuItem.Click += new System.EventHandler(this.employeeDetailToolStripMenuItem_Click);
            // 
            // customerregToolStripMenuItem
            // 
            this.customerregToolStripMenuItem.Name = "customerregToolStripMenuItem";
            this.customerregToolStripMenuItem.Size = new System.Drawing.Size(152, 26);
            this.customerregToolStripMenuItem.Text = "Customer";
            this.customerregToolStripMenuItem.Click += new System.EventHandler(this.customerregToolStripMenuItem_Click);
            // 
            // SupplierregToolStripMenuItem
            // 
            this.SupplierregToolStripMenuItem.Name = "SupplierregToolStripMenuItem";
            this.SupplierregToolStripMenuItem.Size = new System.Drawing.Size(152, 26);
            this.SupplierregToolStripMenuItem.Text = "Supplier";
            this.SupplierregToolStripMenuItem.Click += new System.EventHandler(this.SupplierregToolStripMenuItem_Click);
            // 
            // EmploeeDETAILToolStripMenuItem
            // 
            this.EmploeeDETAILToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.modempToolStripMenuItem,
            this.attenToolStripMenuItem1,
            this.salaryToolStripMenuItem});
            this.EmploeeDETAILToolStripMenuItem.Name = "EmploeeDETAILToolStripMenuItem";
            this.EmploeeDETAILToolStripMenuItem.Size = new System.Drawing.Size(209, 25);
            this.EmploeeDETAILToolStripMenuItem.Text = "EMPLOYEE MANAGEMENT";
            // 
            // modempToolStripMenuItem
            // 
            this.modempToolStripMenuItem.Name = "modempToolStripMenuItem";
            this.modempToolStripMenuItem.Size = new System.Drawing.Size(291, 26);
            this.modempToolStripMenuItem.Text = "Modify Records of registration";
            this.modempToolStripMenuItem.Click += new System.EventHandler(this.modempToolStripMenuItem_Click);
            // 
            // attenToolStripMenuItem1
            // 
            this.attenToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.todaysAttendenceToolStripMenuItem,
            this.attendenceRecordsToolStripMenuItem});
            this.attenToolStripMenuItem1.Name = "attenToolStripMenuItem1";
            this.attenToolStripMenuItem1.Size = new System.Drawing.Size(291, 26);
            this.attenToolStripMenuItem1.Text = "Attendence";
            // 
            // todaysAttendenceToolStripMenuItem
            // 
            this.todaysAttendenceToolStripMenuItem.Name = "todaysAttendenceToolStripMenuItem";
            this.todaysAttendenceToolStripMenuItem.Size = new System.Drawing.Size(218, 26);
            this.todaysAttendenceToolStripMenuItem.Text = "Today\'s Attendence";
            this.todaysAttendenceToolStripMenuItem.Click += new System.EventHandler(this.todaysAttendenceToolStripMenuItem_Click_1);
            // 
            // attendenceRecordsToolStripMenuItem
            // 
            this.attendenceRecordsToolStripMenuItem.Name = "attendenceRecordsToolStripMenuItem";
            this.attendenceRecordsToolStripMenuItem.Size = new System.Drawing.Size(218, 26);
            this.attendenceRecordsToolStripMenuItem.Text = "Attendence Records";
            this.attendenceRecordsToolStripMenuItem.Click += new System.EventHandler(this.attendenceRecordsToolStripMenuItem_Click);
            // 
            // salaryToolStripMenuItem
            // 
            this.salaryToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addToolStripMenuItem,
            this.searchToolStripMenuItem,
            this.updateToolStripMenuItem,
            this.recordsToolStripMenuItem});
            this.salaryToolStripMenuItem.Name = "salaryToolStripMenuItem";
            this.salaryToolStripMenuItem.Size = new System.Drawing.Size(291, 26);
            this.salaryToolStripMenuItem.Text = "Salary Details";
            // 
            // addToolStripMenuItem
            // 
            this.addToolStripMenuItem.Name = "addToolStripMenuItem";
            this.addToolStripMenuItem.Size = new System.Drawing.Size(136, 26);
            this.addToolStripMenuItem.Text = "Add";
            this.addToolStripMenuItem.Click += new System.EventHandler(this.addToolStripMenuItem_Click);
            // 
            // searchToolStripMenuItem
            // 
            this.searchToolStripMenuItem.Name = "searchToolStripMenuItem";
            this.searchToolStripMenuItem.Size = new System.Drawing.Size(136, 26);
            this.searchToolStripMenuItem.Text = "Search";
            this.searchToolStripMenuItem.Click += new System.EventHandler(this.searchToolStripMenuItem_Click);
            // 
            // updateToolStripMenuItem
            // 
            this.updateToolStripMenuItem.Name = "updateToolStripMenuItem";
            this.updateToolStripMenuItem.Size = new System.Drawing.Size(136, 26);
            this.updateToolStripMenuItem.Text = "Update";
            this.updateToolStripMenuItem.Click += new System.EventHandler(this.updateToolStripMenuItem_Click);
            // 
            // recordsToolStripMenuItem
            // 
            this.recordsToolStripMenuItem.Name = "recordsToolStripMenuItem";
            this.recordsToolStripMenuItem.Size = new System.Drawing.Size(136, 26);
            this.recordsToolStripMenuItem.Text = "Records";
            this.recordsToolStripMenuItem.Click += new System.EventHandler(this.recordsToolStripMenuItem_Click);
            // 
            // customerDETAILSToolStripMenuItem
            // 
            this.customerDETAILSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.modifiToolStripMenuItem,
            this.recordsToolStripMenuItem1});
            this.customerDETAILSToolStripMenuItem.Name = "customerDETAILSToolStripMenuItem";
            this.customerDETAILSToolStripMenuItem.Size = new System.Drawing.Size(104, 25);
            this.customerDETAILSToolStripMenuItem.Text = "CUSTOMER";
            this.customerDETAILSToolStripMenuItem.Click += new System.EventHandler(this.customerDETAILSToolStripMenuItem_Click);
            // 
            // modifiToolStripMenuItem
            // 
            this.modifiToolStripMenuItem.Name = "modifiToolStripMenuItem";
            this.modifiToolStripMenuItem.Size = new System.Drawing.Size(291, 26);
            this.modifiToolStripMenuItem.Text = "Modify records of Registration";
            this.modifiToolStripMenuItem.Click += new System.EventHandler(this.modifiToolStripMenuItem_Click);
            // 
            // recordsToolStripMenuItem1
            // 
            this.recordsToolStripMenuItem1.Name = "recordsToolStripMenuItem1";
            this.recordsToolStripMenuItem1.Size = new System.Drawing.Size(291, 26);
            this.recordsToolStripMenuItem1.Text = "View of Records";
            this.recordsToolStripMenuItem1.Click += new System.EventHandler(this.recordsToolStripMenuItem1_Click);
            // 
            // supplierDETAILSToolStripMenuItem
            // 
            this.supplierDETAILSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.modifyToolStripMenuItem,
            this.viewOfRecordsToolStripMenuItem});
            this.supplierDETAILSToolStripMenuItem.Name = "supplierDETAILSToolStripMenuItem";
            this.supplierDETAILSToolStripMenuItem.Size = new System.Drawing.Size(90, 25);
            this.supplierDETAILSToolStripMenuItem.Text = "SUPPLIER";
            // 
            // modifyToolStripMenuItem
            // 
            this.modifyToolStripMenuItem.Name = "modifyToolStripMenuItem";
            this.modifyToolStripMenuItem.Size = new System.Drawing.Size(295, 26);
            this.modifyToolStripMenuItem.Text = "Modify Records of Registration";
            this.modifyToolStripMenuItem.Click += new System.EventHandler(this.modifyToolStripMenuItem_Click);
            // 
            // viewOfRecordsToolStripMenuItem
            // 
            this.viewOfRecordsToolStripMenuItem.Name = "viewOfRecordsToolStripMenuItem";
            this.viewOfRecordsToolStripMenuItem.Size = new System.Drawing.Size(295, 26);
            this.viewOfRecordsToolStripMenuItem.Text = "View of Records";
            this.viewOfRecordsToolStripMenuItem.Click += new System.EventHandler(this.viewOfRecordsToolStripMenuItem_Click);
            // 
            // ordersToolStripMenuItem
            // 
            this.ordersToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.venderToolStripMenuItem1,
            this.customerToolStripMenuItem2});
            this.ordersToolStripMenuItem.Name = "ordersToolStripMenuItem";
            this.ordersToolStripMenuItem.Size = new System.Drawing.Size(82, 25);
            this.ordersToolStripMenuItem.Text = "ORDERS";
            // 
            // venderToolStripMenuItem1
            // 
            this.venderToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dryfruitOrderDetailsToolStripMenuItem2,
            this.spicesOrderDetailsToolStripMenuItem2});
            this.venderToolStripMenuItem1.Name = "venderToolStripMenuItem1";
            this.venderToolStripMenuItem1.Size = new System.Drawing.Size(148, 26);
            this.venderToolStripMenuItem1.Text = "Vender";
            // 
            // dryfruitOrderDetailsToolStripMenuItem2
            // 
            this.dryfruitOrderDetailsToolStripMenuItem2.Name = "dryfruitOrderDetailsToolStripMenuItem2";
            this.dryfruitOrderDetailsToolStripMenuItem2.Size = new System.Drawing.Size(230, 26);
            this.dryfruitOrderDetailsToolStripMenuItem2.Text = "Dryfruit Order Details";
            this.dryfruitOrderDetailsToolStripMenuItem2.Click += new System.EventHandler(this.dryfruitOrderDetailsToolStripMenuItem2_Click);
            // 
            // spicesOrderDetailsToolStripMenuItem2
            // 
            this.spicesOrderDetailsToolStripMenuItem2.Name = "spicesOrderDetailsToolStripMenuItem2";
            this.spicesOrderDetailsToolStripMenuItem2.Size = new System.Drawing.Size(230, 26);
            this.spicesOrderDetailsToolStripMenuItem2.Text = "Spices Order Details";
            this.spicesOrderDetailsToolStripMenuItem2.Click += new System.EventHandler(this.spicesOrderDetailsToolStripMenuItem2_Click);
            // 
            // customerToolStripMenuItem2
            // 
            this.customerToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dryFruitOrderDetailsToolStripMenuItem3,
            this.spicesOrderDetailsToolStripMenuItem3});
            this.customerToolStripMenuItem2.Name = "customerToolStripMenuItem2";
            this.customerToolStripMenuItem2.Size = new System.Drawing.Size(148, 26);
            this.customerToolStripMenuItem2.Text = "Customer";
            // 
            // dryFruitOrderDetailsToolStripMenuItem3
            // 
            this.dryFruitOrderDetailsToolStripMenuItem3.Name = "dryFruitOrderDetailsToolStripMenuItem3";
            this.dryFruitOrderDetailsToolStripMenuItem3.Size = new System.Drawing.Size(233, 26);
            this.dryFruitOrderDetailsToolStripMenuItem3.Text = "DryFruit Order Details";
            this.dryFruitOrderDetailsToolStripMenuItem3.Click += new System.EventHandler(this.dryFruitOrderDetailsToolStripMenuItem3_Click);
            // 
            // spicesOrderDetailsToolStripMenuItem3
            // 
            this.spicesOrderDetailsToolStripMenuItem3.Name = "spicesOrderDetailsToolStripMenuItem3";
            this.spicesOrderDetailsToolStripMenuItem3.Size = new System.Drawing.Size(233, 26);
            this.spicesOrderDetailsToolStripMenuItem3.Text = "Spices Order Details";
            this.spicesOrderDetailsToolStripMenuItem3.Click += new System.EventHandler(this.spicesOrderDetailsToolStripMenuItem3_Click);
            // 
            // billToolStripMenuItem
            // 
            this.billToolStripMenuItem.Name = "billToolStripMenuItem";
            this.billToolStripMenuItem.Size = new System.Drawing.Size(51, 25);
            this.billToolStripMenuItem.Text = "BILL";
            this.billToolStripMenuItem.Click += new System.EventHandler(this.billToolStripMenuItem_Click);
            // 
            // rEPORTSToolStripMenuItem1
            // 
            this.rEPORTSToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dryFruitReportToolStripMenuItem1,
            this.spicesReportToolStripMenuItem1,
            this.employeeReportToolStripMenuItem1,
            this.emploeeSalaryReportToolStripMenuItem1,
            this.employeeAttendenceReportToolStripMenuItem1,
            this.customerReportToolStripMenuItem1,
            this.supplierReportsToolStripMenuItem1,
            this.billReportToolStripMenuItem1});
            this.rEPORTSToolStripMenuItem1.Name = "rEPORTSToolStripMenuItem1";
            this.rEPORTSToolStripMenuItem1.Size = new System.Drawing.Size(88, 25);
            this.rEPORTSToolStripMenuItem1.Text = "REPORTS";
            // 
            // dryFruitReportToolStripMenuItem1
            // 
            this.dryFruitReportToolStripMenuItem1.Name = "dryFruitReportToolStripMenuItem1";
            this.dryFruitReportToolStripMenuItem1.Size = new System.Drawing.Size(281, 26);
            this.dryFruitReportToolStripMenuItem1.Text = "DryFruit Report";
            this.dryFruitReportToolStripMenuItem1.Click += new System.EventHandler(this.dryFruitReportToolStripMenuItem1_Click);
            // 
            // spicesReportToolStripMenuItem1
            // 
            this.spicesReportToolStripMenuItem1.Name = "spicesReportToolStripMenuItem1";
            this.spicesReportToolStripMenuItem1.Size = new System.Drawing.Size(281, 26);
            this.spicesReportToolStripMenuItem1.Text = "Spices Report";
            this.spicesReportToolStripMenuItem1.Click += new System.EventHandler(this.spicesReportToolStripMenuItem1_Click);
            // 
            // employeeReportToolStripMenuItem1
            // 
            this.employeeReportToolStripMenuItem1.Name = "employeeReportToolStripMenuItem1";
            this.employeeReportToolStripMenuItem1.Size = new System.Drawing.Size(281, 26);
            this.employeeReportToolStripMenuItem1.Text = "Employee Report";
            this.employeeReportToolStripMenuItem1.Click += new System.EventHandler(this.employeeReportToolStripMenuItem1_Click);
            // 
            // emploeeSalaryReportToolStripMenuItem1
            // 
            this.emploeeSalaryReportToolStripMenuItem1.Name = "emploeeSalaryReportToolStripMenuItem1";
            this.emploeeSalaryReportToolStripMenuItem1.Size = new System.Drawing.Size(281, 26);
            this.emploeeSalaryReportToolStripMenuItem1.Text = "Emploee Salary Report";
            this.emploeeSalaryReportToolStripMenuItem1.Click += new System.EventHandler(this.emploeeSalaryReportToolStripMenuItem1_Click);
            // 
            // employeeAttendenceReportToolStripMenuItem1
            // 
            this.employeeAttendenceReportToolStripMenuItem1.Name = "employeeAttendenceReportToolStripMenuItem1";
            this.employeeAttendenceReportToolStripMenuItem1.Size = new System.Drawing.Size(281, 26);
            this.employeeAttendenceReportToolStripMenuItem1.Text = "Employee Attendence Report";
            this.employeeAttendenceReportToolStripMenuItem1.Click += new System.EventHandler(this.employeeAttendenceReportToolStripMenuItem1_Click);
            // 
            // customerReportToolStripMenuItem1
            // 
            this.customerReportToolStripMenuItem1.Name = "customerReportToolStripMenuItem1";
            this.customerReportToolStripMenuItem1.Size = new System.Drawing.Size(281, 26);
            this.customerReportToolStripMenuItem1.Text = "Customer Report";
            this.customerReportToolStripMenuItem1.Click += new System.EventHandler(this.customerReportToolStripMenuItem1_Click);
            // 
            // supplierReportsToolStripMenuItem1
            // 
            this.supplierReportsToolStripMenuItem1.Name = "supplierReportsToolStripMenuItem1";
            this.supplierReportsToolStripMenuItem1.Size = new System.Drawing.Size(281, 26);
            this.supplierReportsToolStripMenuItem1.Text = "Supplier Reports";
            this.supplierReportsToolStripMenuItem1.Click += new System.EventHandler(this.supplierReportsToolStripMenuItem1_Click);
            // 
            // billReportToolStripMenuItem1
            // 
            this.billReportToolStripMenuItem1.Name = "billReportToolStripMenuItem1";
            this.billReportToolStripMenuItem1.Size = new System.Drawing.Size(281, 26);
            this.billReportToolStripMenuItem1.Text = "Bill Report";
            this.billReportToolStripMenuItem1.Click += new System.EventHandler(this.billReportToolStripMenuItem1_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 405);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1275, 48);
            this.panel1.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(296, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 20);
            this.label2.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(32, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(223, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "CURRENT DATE AND TIME:-";
            // 
            // MDIParent1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1275, 453);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Name = "MDIParent1";
            this.Text = "MDIParent1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MDIParent1_Load);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion


        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem pRODUCTDETAILSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem RegistrationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem EmploeeDETAILToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem customerDETAILSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem supplierDETAILSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ordersToolStripMenuItem;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem dRYFRUITDETAILSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addDryFruitDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchDryFruitDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateDryFruitDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewDryFruitDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewDryFruitDetailsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem spicesDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addSpicesDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchSpicesDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateSpicesDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteSpicesRecordsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewSpicesDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem employeeDetailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem customerregToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SupplierregToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem modempToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem billToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem attenToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem todaysAttendenceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem attendenceRecordsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salaryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem recordsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rEPORTSToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem dryFruitReportToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem spicesReportToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem employeeReportToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem emploeeSalaryReportToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem employeeAttendenceReportToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem venderToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem dryfruitOrderDetailsToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem spicesOrderDetailsToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem customerToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem dryFruitOrderDetailsToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem spicesOrderDetailsToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem customerReportToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem supplierReportsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem billReportToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem modifiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem modifyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem recordsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem viewOfRecordsToolStripMenuItem;
    }
}



