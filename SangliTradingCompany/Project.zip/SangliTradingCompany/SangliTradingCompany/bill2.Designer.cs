﻿namespace SangliTradingCompany
{
    partial class bill2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comp_combo = new System.Windows.Forms.ComboBox();
            this.lastname_combo = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.Firstname_combo = new System.Windows.Forms.ComboBox();
            this.add_txt = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.bill_number = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.amount = new System.Windows.Forms.Button();
            this.amount1_txt = new System.Windows.Forms.TextBox();
            this.price1_txt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.netkg1_txt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.q1_txt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.proname1_combo = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.new_btn = new System.Windows.Forms.Button();
            this.Cancel_btn = new System.Windows.Forms.Button();
            this.Save_btn = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.comp_combo);
            this.groupBox1.Controls.Add(this.lastname_combo);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.Firstname_combo);
            this.groupBox1.Controls.Add(this.add_txt);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(41, 26);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(519, 183);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Customer Details";
            // 
            // comp_combo
            // 
            this.comp_combo.FormattingEnabled = true;
            this.comp_combo.Location = new System.Drawing.Point(181, 86);
            this.comp_combo.Name = "comp_combo";
            this.comp_combo.Size = new System.Drawing.Size(121, 24);
            this.comp_combo.TabIndex = 9;
            // 
            // lastname_combo
            // 
            this.lastname_combo.FormattingEnabled = true;
            this.lastname_combo.Location = new System.Drawing.Point(181, 56);
            this.lastname_combo.Name = "lastname_combo";
            this.lastname_combo.Size = new System.Drawing.Size(121, 24);
            this.lastname_combo.TabIndex = 8;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(30, 66);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(76, 17);
            this.label11.TabIndex = 7;
            this.label11.Text = "Last Name";
            // 
            // Firstname_combo
            // 
            this.Firstname_combo.FormattingEnabled = true;
            this.Firstname_combo.Location = new System.Drawing.Point(181, 18);
            this.Firstname_combo.Name = "Firstname_combo";
            this.Firstname_combo.Size = new System.Drawing.Size(121, 24);
            this.Firstname_combo.TabIndex = 6;
            // 
            // add_txt
            // 
            this.add_txt.Location = new System.Drawing.Point(181, 116);
            this.add_txt.Multiline = true;
            this.add_txt.Name = "add_txt";
            this.add_txt.Size = new System.Drawing.Size(222, 49);
            this.add_txt.TabIndex = 4;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(30, 94);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(108, 17);
            this.label8.TabIndex = 2;
            this.label8.Text = "Company Name";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(30, 140);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 17);
            this.label7.TabIndex = 1;
            this.label7.Text = "Address";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(30, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 17);
            this.label6.TabIndex = 0;
            this.label6.Text = "Name";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.dateTimePicker1);
            this.groupBox2.Controls.Add(this.bill_number);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(676, 44);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(383, 117);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(139, 55);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 23);
            this.dateTimePicker1.TabIndex = 3;
            // 
            // bill_number
            // 
            this.bill_number.Location = new System.Drawing.Point(139, 19);
            this.bill_number.Name = "bill_number";
            this.bill_number.Size = new System.Drawing.Size(100, 23);
            this.bill_number.TabIndex = 2;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(20, 55);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(38, 17);
            this.label10.TabIndex = 1;
            this.label10.Text = "Date";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(17, 25);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(78, 17);
            this.label9.TabIndex = 0;
            this.label9.Text = "Bill number";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.amount);
            this.groupBox3.Controls.Add(this.amount1_txt);
            this.groupBox3.Controls.Add(this.price1_txt);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.netkg1_txt);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.q1_txt);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.proname1_combo);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Location = new System.Drawing.Point(129, 253);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1085, 100);
            this.groupBox3.TabIndex = 7;
            this.groupBox3.TabStop = false;
            // 
            // amount
            // 
            this.amount.Location = new System.Drawing.Point(872, 32);
            this.amount.Name = "amount";
            this.amount.Size = new System.Drawing.Size(75, 23);
            this.amount.TabIndex = 25;
            this.amount.Text = "Amount";
            this.amount.UseVisualStyleBackColor = true;
            this.amount.Click += new System.EventHandler(this.amount_Click);
            // 
            // amount1_txt
            // 
            this.amount1_txt.Location = new System.Drawing.Point(964, 35);
            this.amount1_txt.Name = "amount1_txt";
            this.amount1_txt.Size = new System.Drawing.Size(100, 20);
            this.amount1_txt.TabIndex = 24;
            this.amount1_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // price1_txt
            // 
            this.price1_txt.Location = new System.Drawing.Point(758, 34);
            this.price1_txt.Name = "price1_txt";
            this.price1_txt.Size = new System.Drawing.Size(100, 20);
            this.price1_txt.TabIndex = 19;
            this.price1_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(698, 42);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 13);
            this.label5.TabIndex = 16;
            this.label5.Text = "Price";
            // 
            // netkg1_txt
            // 
            this.netkg1_txt.Location = new System.Drawing.Point(542, 35);
            this.netkg1_txt.Name = "netkg1_txt";
            this.netkg1_txt.Size = new System.Drawing.Size(100, 20);
            this.netkg1_txt.TabIndex = 15;
            this.netkg1_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(479, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Net Kg.";
            // 
            // q1_txt
            // 
            this.q1_txt.Location = new System.Drawing.Point(343, 35);
            this.q1_txt.Name = "q1_txt";
            this.q1_txt.Size = new System.Drawing.Size(100, 20);
            this.q1_txt.TabIndex = 11;
            this.q1_txt.TextChanged += new System.EventHandler(this.validTextInteger);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(290, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Quntity";
            // 
            // proname1_combo
            // 
            this.proname1_combo.FormattingEnabled = true;
            this.proname1_combo.Items.AddRange(new object[] {
            "Badam",
            "Kaju",
            "Khajoor",
            "Pista",
            "Kishmish",
            "Akhrot",
            "Dalchini  ",
            "Laung",
            "Dhania  ",
            "Jaiphal ",
            "Chakra_Phool",
            "Haldi ",
            "Haldi_Powder",
            "Kali_Elaichi",
            "Jeera "});
            this.proname1_combo.Location = new System.Drawing.Point(130, 34);
            this.proname1_combo.Name = "proname1_combo";
            this.proname1_combo.Size = new System.Drawing.Size(121, 21);
            this.proname1_combo.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(15, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Product Name";
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.Transparent;
            this.groupBox4.Controls.Add(this.new_btn);
            this.groupBox4.Controls.Add(this.Cancel_btn);
            this.groupBox4.Controls.Add(this.Save_btn);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(272, 399);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(804, 83);
            this.groupBox4.TabIndex = 27;
            this.groupBox4.TabStop = false;
            // 
            // new_btn
            // 
            this.new_btn.Location = new System.Drawing.Point(22, 34);
            this.new_btn.Name = "new_btn";
            this.new_btn.Size = new System.Drawing.Size(75, 23);
            this.new_btn.TabIndex = 2;
            this.new_btn.Text = "New";
            this.new_btn.UseVisualStyleBackColor = true;
            this.new_btn.Click += new System.EventHandler(this.new_btn_Click_1);
            // 
            // Cancel_btn
            // 
            this.Cancel_btn.Location = new System.Drawing.Point(712, 34);
            this.Cancel_btn.Name = "Cancel_btn";
            this.Cancel_btn.Size = new System.Drawing.Size(75, 23);
            this.Cancel_btn.TabIndex = 1;
            this.Cancel_btn.Text = "Cancel";
            this.Cancel_btn.UseVisualStyleBackColor = true;
            this.Cancel_btn.Click += new System.EventHandler(this.Cancel_btn_Click);
            // 
            // Save_btn
            // 
            this.Save_btn.Location = new System.Drawing.Point(399, 34);
            this.Save_btn.Name = "Save_btn";
            this.Save_btn.Size = new System.Drawing.Size(75, 23);
            this.Save_btn.TabIndex = 0;
            this.Save_btn.Text = "Save";
            this.Save_btn.UseVisualStyleBackColor = true;
            this.Save_btn.Click += new System.EventHandler(this.Save_btn_Click);
            // 
            // bill2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1331, 638);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "bill2";
            this.Text = "bill2";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.bill2_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox comp_combo;
        private System.Windows.Forms.ComboBox lastname_combo;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox Firstname_combo;
        private System.Windows.Forms.TextBox add_txt;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox bill_number;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox proname1_combo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox q1_txt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox netkg1_txt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox price1_txt;
        private System.Windows.Forms.TextBox amount1_txt;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button new_btn;
        private System.Windows.Forms.Button Cancel_btn;
        private System.Windows.Forms.Button Save_btn;
        private System.Windows.Forms.Button amount;
    }
}