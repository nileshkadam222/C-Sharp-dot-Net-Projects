﻿namespace SangliTradingCompany
{
    partial class Bill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.proname5_combo = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.proname1_combo = new System.Windows.Forms.ComboBox();
            this.proname2_combo = new System.Windows.Forms.ComboBox();
            this.proname3_combo = new System.Windows.Forms.ComboBox();
            this.proname4_combo = new System.Windows.Forms.ComboBox();
            this.q1_txt = new System.Windows.Forms.TextBox();
            this.q2_txt = new System.Windows.Forms.TextBox();
            this.q3_txt = new System.Windows.Forms.TextBox();
            this.q4_txt = new System.Windows.Forms.TextBox();
            this.netkg1_txt = new System.Windows.Forms.TextBox();
            this.netkg2_txt = new System.Windows.Forms.TextBox();
            this.netkg3_txt = new System.Windows.Forms.TextBox();
            this.netkg4_txt = new System.Windows.Forms.TextBox();
            this.price1_txt = new System.Windows.Forms.TextBox();
            this.price2_txt = new System.Windows.Forms.TextBox();
            this.price3_txt = new System.Windows.Forms.TextBox();
            this.price4_txt = new System.Windows.Forms.TextBox();
            this.amount3_txt = new System.Windows.Forms.TextBox();
            this.amount4_txt = new System.Windows.Forms.TextBox();
            this.amount1_txt = new System.Windows.Forms.TextBox();
            this.amount2_txt = new System.Windows.Forms.TextBox();
            this.q5_txt = new System.Windows.Forms.TextBox();
            this.netkg5_txt = new System.Windows.Forms.TextBox();
            this.price5_txt = new System.Windows.Forms.TextBox();
            this.amount5_txt = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.bill_number = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.add_txt = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comp_combo = new System.Windows.Forms.ComboBox();
            this.lastname_combo = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.Firstname_combo = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.total_amount_txt = new System.Windows.Forms.TextBox();
            this.total_btn = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.new_btn = new System.Windows.Forms.Button();
            this.Cancel_btn = new System.Windows.Forms.Button();
            this.Save_btn = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 133F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 134F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 125F));
            this.tableLayoutPanel1.Controls.Add(this.proname5_combo, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label3, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label4, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label5, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.label1, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.proname1_combo, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.proname2_combo, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.proname3_combo, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.proname4_combo, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.q1_txt, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.q2_txt, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.q3_txt, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.q4_txt, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.netkg1_txt, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.netkg2_txt, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.netkg3_txt, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.netkg4_txt, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.price1_txt, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.price2_txt, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.price3_txt, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.price4_txt, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.amount3_txt, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.amount4_txt, 4, 4);
            this.tableLayoutPanel1.Controls.Add(this.amount1_txt, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.amount2_txt, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.q5_txt, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.netkg5_txt, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.price5_txt, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.amount5_txt, 4, 5);
            this.tableLayoutPanel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel1.Location = new System.Drawing.Point(227, 233);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 34.21053F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 65.78947F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(764, 254);
            this.tableLayoutPanel1.TabIndex = 3;
            // 
            // proname5_combo
            // 
            this.proname5_combo.FormattingEnabled = true;
            this.proname5_combo.Items.AddRange(new object[] {
            "Badam",
            "Kaju",
            "Khajoor",
            "Pista",
            "Kishmish",
            "Akhrot"});
            this.proname5_combo.Location = new System.Drawing.Point(3, 222);
            this.proname5_combo.Name = "proname5_combo";
            this.proname5_combo.Size = new System.Drawing.Size(121, 24);
            this.proname5_combo.TabIndex = 27;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Product Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(255, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Quntity";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(388, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Net Kg.";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(522, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Price";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(642, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Amount";
            // 
            // proname1_combo
            // 
            this.proname1_combo.FormattingEnabled = true;
            this.proname1_combo.Items.AddRange(new object[] {
            "Badam",
            "Kaju",
            "Khajoor",
            "Pista",
            "Kishmish",
            "Akhrot"});
            this.proname1_combo.Location = new System.Drawing.Point(3, 35);
            this.proname1_combo.Name = "proname1_combo";
            this.proname1_combo.Size = new System.Drawing.Size(121, 24);
            this.proname1_combo.TabIndex = 6;
            // 
            // proname2_combo
            // 
            this.proname2_combo.FormattingEnabled = true;
            this.proname2_combo.Items.AddRange(new object[] {
            "Badam",
            "Kaju",
            "Khajoor",
            "Pista",
            "Kishmish",
            "Akhrot"});
            this.proname2_combo.Location = new System.Drawing.Point(3, 97);
            this.proname2_combo.Name = "proname2_combo";
            this.proname2_combo.Size = new System.Drawing.Size(121, 24);
            this.proname2_combo.TabIndex = 7;
            // 
            // proname3_combo
            // 
            this.proname3_combo.FormattingEnabled = true;
            this.proname3_combo.Items.AddRange(new object[] {
            "Badam",
            "Kaju",
            "Khajoor",
            "Pista",
            "Kishmish",
            "Akhrot"});
            this.proname3_combo.Location = new System.Drawing.Point(3, 142);
            this.proname3_combo.Name = "proname3_combo";
            this.proname3_combo.Size = new System.Drawing.Size(121, 24);
            this.proname3_combo.TabIndex = 8;
            // 
            // proname4_combo
            // 
            this.proname4_combo.FormattingEnabled = true;
            this.proname4_combo.Items.AddRange(new object[] {
            "Badam",
            "Kaju",
            "Khajoor",
            "Pista",
            "Kishmish",
            "Akhrot"});
            this.proname4_combo.Location = new System.Drawing.Point(3, 187);
            this.proname4_combo.Name = "proname4_combo";
            this.proname4_combo.Size = new System.Drawing.Size(121, 24);
            this.proname4_combo.TabIndex = 9;
            // 
            // q1_txt
            // 
            this.q1_txt.Location = new System.Drawing.Point(255, 35);
            this.q1_txt.Name = "q1_txt";
            this.q1_txt.Size = new System.Drawing.Size(100, 23);
            this.q1_txt.TabIndex = 10;
            // 
            // q2_txt
            // 
            this.q2_txt.Location = new System.Drawing.Point(255, 97);
            this.q2_txt.Name = "q2_txt";
            this.q2_txt.Size = new System.Drawing.Size(100, 23);
            this.q2_txt.TabIndex = 11;
            // 
            // q3_txt
            // 
            this.q3_txt.Location = new System.Drawing.Point(255, 142);
            this.q3_txt.Name = "q3_txt";
            this.q3_txt.Size = new System.Drawing.Size(100, 23);
            this.q3_txt.TabIndex = 12;
            // 
            // q4_txt
            // 
            this.q4_txt.Location = new System.Drawing.Point(255, 187);
            this.q4_txt.Name = "q4_txt";
            this.q4_txt.Size = new System.Drawing.Size(100, 23);
            this.q4_txt.TabIndex = 13;
            // 
            // netkg1_txt
            // 
            this.netkg1_txt.Location = new System.Drawing.Point(388, 35);
            this.netkg1_txt.Name = "netkg1_txt";
            this.netkg1_txt.Size = new System.Drawing.Size(100, 23);
            this.netkg1_txt.TabIndex = 14;
            // 
            // netkg2_txt
            // 
            this.netkg2_txt.Location = new System.Drawing.Point(388, 97);
            this.netkg2_txt.Name = "netkg2_txt";
            this.netkg2_txt.Size = new System.Drawing.Size(100, 23);
            this.netkg2_txt.TabIndex = 15;
            // 
            // netkg3_txt
            // 
            this.netkg3_txt.Location = new System.Drawing.Point(388, 142);
            this.netkg3_txt.Name = "netkg3_txt";
            this.netkg3_txt.Size = new System.Drawing.Size(100, 23);
            this.netkg3_txt.TabIndex = 16;
            // 
            // netkg4_txt
            // 
            this.netkg4_txt.Location = new System.Drawing.Point(388, 187);
            this.netkg4_txt.Name = "netkg4_txt";
            this.netkg4_txt.Size = new System.Drawing.Size(100, 23);
            this.netkg4_txt.TabIndex = 17;
            // 
            // price1_txt
            // 
            this.price1_txt.Location = new System.Drawing.Point(522, 35);
            this.price1_txt.Name = "price1_txt";
            this.price1_txt.Size = new System.Drawing.Size(100, 23);
            this.price1_txt.TabIndex = 18;
            // 
            // price2_txt
            // 
            this.price2_txt.Location = new System.Drawing.Point(522, 97);
            this.price2_txt.Name = "price2_txt";
            this.price2_txt.Size = new System.Drawing.Size(100, 23);
            this.price2_txt.TabIndex = 19;
            // 
            // price3_txt
            // 
            this.price3_txt.Location = new System.Drawing.Point(522, 142);
            this.price3_txt.Name = "price3_txt";
            this.price3_txt.Size = new System.Drawing.Size(100, 23);
            this.price3_txt.TabIndex = 20;
            // 
            // price4_txt
            // 
            this.price4_txt.Location = new System.Drawing.Point(522, 187);
            this.price4_txt.Name = "price4_txt";
            this.price4_txt.Size = new System.Drawing.Size(100, 23);
            this.price4_txt.TabIndex = 21;
            // 
            // amount3_txt
            // 
            this.amount3_txt.Location = new System.Drawing.Point(642, 142);
            this.amount3_txt.Name = "amount3_txt";
            this.amount3_txt.Size = new System.Drawing.Size(100, 23);
            this.amount3_txt.TabIndex = 24;
            this.amount3_txt.TextChanged += new System.EventHandler(this.amount3_txt_TextChanged);
            // 
            // amount4_txt
            // 
            this.amount4_txt.Location = new System.Drawing.Point(642, 187);
            this.amount4_txt.Name = "amount4_txt";
            this.amount4_txt.Size = new System.Drawing.Size(100, 23);
            this.amount4_txt.TabIndex = 25;
            this.amount4_txt.TextChanged += new System.EventHandler(this.amount4_txt_TextChanged);
            // 
            // amount1_txt
            // 
            this.amount1_txt.Location = new System.Drawing.Point(642, 35);
            this.amount1_txt.Name = "amount1_txt";
            this.amount1_txt.Size = new System.Drawing.Size(100, 23);
            this.amount1_txt.TabIndex = 23;
            this.amount1_txt.TextChanged += new System.EventHandler(this.amount1_txt_TextChanged);
            // 
            // amount2_txt
            // 
            this.amount2_txt.Location = new System.Drawing.Point(642, 97);
            this.amount2_txt.Name = "amount2_txt";
            this.amount2_txt.Size = new System.Drawing.Size(100, 23);
            this.amount2_txt.TabIndex = 22;
            this.amount2_txt.TextChanged += new System.EventHandler(this.amount2_txt_TextChanged);
            // 
            // q5_txt
            // 
            this.q5_txt.Location = new System.Drawing.Point(255, 222);
            this.q5_txt.Name = "q5_txt";
            this.q5_txt.Size = new System.Drawing.Size(100, 23);
            this.q5_txt.TabIndex = 28;
            // 
            // netkg5_txt
            // 
            this.netkg5_txt.Location = new System.Drawing.Point(388, 222);
            this.netkg5_txt.Name = "netkg5_txt";
            this.netkg5_txt.Size = new System.Drawing.Size(100, 23);
            this.netkg5_txt.TabIndex = 29;
            // 
            // price5_txt
            // 
            this.price5_txt.Location = new System.Drawing.Point(522, 222);
            this.price5_txt.Name = "price5_txt";
            this.price5_txt.Size = new System.Drawing.Size(100, 23);
            this.price5_txt.TabIndex = 30;
            // 
            // amount5_txt
            // 
            this.amount5_txt.Location = new System.Drawing.Point(642, 222);
            this.amount5_txt.Name = "amount5_txt";
            this.amount5_txt.Size = new System.Drawing.Size(100, 23);
            this.amount5_txt.TabIndex = 31;
            this.amount5_txt.TextChanged += new System.EventHandler(this.amount5_txt_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(30, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 17);
            this.label6.TabIndex = 0;
            this.label6.Text = "Name";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(30, 140);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 17);
            this.label7.TabIndex = 1;
            this.label7.Text = "Address";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.dateTimePicker1);
            this.groupBox2.Controls.Add(this.bill_number);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(752, 23);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(383, 117);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(139, 55);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 23);
            this.dateTimePicker1.TabIndex = 3;
            // 
            // bill_number
            // 
            this.bill_number.Location = new System.Drawing.Point(139, 19);
            this.bill_number.Name = "bill_number";
            this.bill_number.Size = new System.Drawing.Size(100, 23);
            this.bill_number.TabIndex = 2;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(20, 55);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(38, 17);
            this.label10.TabIndex = 1;
            this.label10.Text = "Date";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(17, 25);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(78, 17);
            this.label9.TabIndex = 0;
            this.label9.Text = "Bill number";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(30, 94);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(108, 17);
            this.label8.TabIndex = 2;
            this.label8.Text = "Company Name";
            // 
            // add_txt
            // 
            this.add_txt.Location = new System.Drawing.Point(181, 116);
            this.add_txt.Multiline = true;
            this.add_txt.Name = "add_txt";
            this.add_txt.Size = new System.Drawing.Size(222, 49);
            this.add_txt.TabIndex = 4;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.comp_combo);
            this.groupBox1.Controls.Add(this.lastname_combo);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.Firstname_combo);
            this.groupBox1.Controls.Add(this.add_txt);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(227, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(519, 183);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Customer Details";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // comp_combo
            // 
            this.comp_combo.FormattingEnabled = true;
            this.comp_combo.Location = new System.Drawing.Point(181, 86);
            this.comp_combo.Name = "comp_combo";
            this.comp_combo.Size = new System.Drawing.Size(121, 24);
            this.comp_combo.TabIndex = 9;
            // 
            // lastname_combo
            // 
            this.lastname_combo.FormattingEnabled = true;
            this.lastname_combo.Location = new System.Drawing.Point(181, 56);
            this.lastname_combo.Name = "lastname_combo";
            this.lastname_combo.Size = new System.Drawing.Size(121, 24);
            this.lastname_combo.TabIndex = 8;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(30, 66);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(76, 17);
            this.label11.TabIndex = 7;
            this.label11.Text = "Last Name";
            // 
            // Firstname_combo
            // 
            this.Firstname_combo.FormattingEnabled = true;
            this.Firstname_combo.Location = new System.Drawing.Point(181, 18);
            this.Firstname_combo.Name = "Firstname_combo";
            this.Firstname_combo.Size = new System.Drawing.Size(121, 24);
            this.Firstname_combo.TabIndex = 6;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Transparent;
            this.groupBox3.Controls.Add(this.total_amount_txt);
            this.groupBox3.Controls.Add(this.total_btn);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(455, 504);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(463, 59);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Total Amount";
            // 
            // total_amount_txt
            // 
            this.total_amount_txt.Location = new System.Drawing.Point(283, 22);
            this.total_amount_txt.Name = "total_amount_txt";
            this.total_amount_txt.Size = new System.Drawing.Size(100, 23);
            this.total_amount_txt.TabIndex = 7;
            // 
            // total_btn
            // 
            this.total_btn.Location = new System.Drawing.Point(126, 19);
            this.total_btn.Name = "total_btn";
            this.total_btn.Size = new System.Drawing.Size(117, 23);
            this.total_btn.TabIndex = 0;
            this.total_btn.Text = "Total Amount";
            this.total_btn.UseVisualStyleBackColor = true;
            this.total_btn.Click += new System.EventHandler(this.total_btn_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.Transparent;
            this.groupBox4.Controls.Add(this.new_btn);
            this.groupBox4.Controls.Add(this.Cancel_btn);
            this.groupBox4.Controls.Add(this.Save_btn);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(254, 569);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(804, 44);
            this.groupBox4.TabIndex = 26;
            this.groupBox4.TabStop = false;
            // 
            // new_btn
            // 
            this.new_btn.Location = new System.Drawing.Point(22, 13);
            this.new_btn.Name = "new_btn";
            this.new_btn.Size = new System.Drawing.Size(75, 23);
            this.new_btn.TabIndex = 2;
            this.new_btn.Text = "New";
            this.new_btn.UseVisualStyleBackColor = true;
            this.new_btn.Click += new System.EventHandler(this.new_btn_Click);
            // 
            // Cancel_btn
            // 
            this.Cancel_btn.Location = new System.Drawing.Point(618, 13);
            this.Cancel_btn.Name = "Cancel_btn";
            this.Cancel_btn.Size = new System.Drawing.Size(75, 23);
            this.Cancel_btn.TabIndex = 1;
            this.Cancel_btn.Text = "Cancel";
            this.Cancel_btn.UseVisualStyleBackColor = true;
            this.Cancel_btn.Click += new System.EventHandler(this.Cancel_btn_Click);
            // 
            // Save_btn
            // 
            this.Save_btn.Location = new System.Drawing.Point(386, 13);
            this.Save_btn.Name = "Save_btn";
            this.Save_btn.Size = new System.Drawing.Size(75, 23);
            this.Save_btn.TabIndex = 0;
            this.Save_btn.Text = "Save";
            this.Save_btn.UseVisualStyleBackColor = true;
            this.Save_btn.Click += new System.EventHandler(this.Save_btn_Click);
            // 
            // Bill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1313, 625);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox4);
            this.Name = "Bill";
            this.Text = "Bill";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Bill_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox proname1_combo;
        private System.Windows.Forms.ComboBox proname2_combo;
        private System.Windows.Forms.ComboBox proname3_combo;
        private System.Windows.Forms.ComboBox proname4_combo;
        private System.Windows.Forms.TextBox q1_txt;
        private System.Windows.Forms.TextBox q2_txt;
        private System.Windows.Forms.TextBox q3_txt;
        private System.Windows.Forms.TextBox q4_txt;
        private System.Windows.Forms.TextBox netkg1_txt;
        private System.Windows.Forms.TextBox netkg2_txt;
        private System.Windows.Forms.TextBox netkg3_txt;
        private System.Windows.Forms.TextBox netkg4_txt;
        private System.Windows.Forms.TextBox price1_txt;
        private System.Windows.Forms.TextBox price2_txt;
        private System.Windows.Forms.TextBox price3_txt;
        private System.Windows.Forms.TextBox price4_txt;
        private System.Windows.Forms.TextBox amount2_txt;
        private System.Windows.Forms.TextBox amount1_txt;
        private System.Windows.Forms.TextBox amount3_txt;
        private System.Windows.Forms.TextBox amount4_txt;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox bill_number;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox add_txt;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox Firstname_combo;
        private System.Windows.Forms.ComboBox comp_combo;
        private System.Windows.Forms.ComboBox lastname_combo;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox total_amount_txt;
        private System.Windows.Forms.Button total_btn;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ComboBox proname5_combo;
        private System.Windows.Forms.TextBox q5_txt;
        private System.Windows.Forms.TextBox netkg5_txt;
        private System.Windows.Forms.TextBox price5_txt;
        private System.Windows.Forms.TextBox amount5_txt;
        private System.Windows.Forms.Button Cancel_btn;
        private System.Windows.Forms.Button Save_btn;
        private System.Windows.Forms.Button new_btn;
    }
}