using System;
using System.Web;
using System.Collections;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Data;
using System.Data.SqlClient;


/// <summary>
/// Summary description for sharebooksws
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class sharebooksws : System.Web.Services.WebService {

    public sharebooksws () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public DataSet GetBooks()
    {
        SqlConnection con = new SqlConnection(Database.ConnectionString);
        SqlDataAdapter da = new SqlDataAdapter("select * from books", con);
        DataSet ds = new DataSet();
        da.Fill(ds,"books");
        return ds;
    }

    [WebMethod]
    public DataSet GetRecentBooks(int topn)
    {
        SqlConnection con = new SqlConnection(Database.ConnectionString);
        SqlDataAdapter da = new SqlDataAdapter("select top " + topn.ToString() + " * from books order by bookid desc", con);
        DataSet ds = new DataSet();
        da.Fill(ds, "books");
        return ds;
    }

    [WebMethod]
    public DataSet GetUsers()
    {
        SqlConnection con = new SqlConnection(Database.ConnectionString);
        SqlDataAdapter da = new SqlDataAdapter("select * from users", con);
        DataSet ds = new DataSet();
        da.Fill(ds, "users");
        return ds;
    }

    [WebMethod]
    public int GetBooksCount()
    {
        SqlConnection con = new SqlConnection(Database.ConnectionString);
        con.Open();
        SqlCommand cmd = new SqlCommand("select count(*) from books", con);
        int count = (int) cmd.ExecuteScalar();
        con.Close();
        return count;
    }


    
}

