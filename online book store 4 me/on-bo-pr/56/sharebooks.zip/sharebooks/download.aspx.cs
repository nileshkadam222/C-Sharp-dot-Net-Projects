using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class download : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)  // first request
            Session.Add("bookid", Request.QueryString["bookid"]);

    }
    protected void btnFeedback_Click(object sender, EventArgs e)
    {
        if ( ddlRating.SelectedIndex == 0 ) 
        {
            lblMsg.Text = "Please select your rating!";
            return;
        }

        // call storedprocedure for updation of book
        SqlConnection con = new SqlConnection(Database.ConnectionString);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("updatebookrating", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@bookid", SqlDbType.Int).Value = Session["bookid"];
            cmd.Parameters.Add("@rating", SqlDbType.Char, 1).Value = ddlRating.SelectedItem.Value;

            cmd.ExecuteNonQuery();
            lblMsg.Text = "Thank you for your valuable feedback!";

        }
        catch (Exception ex)
        {
            lblMsg.Text = "Error -->" + ex.Message;
        }
        finally
        {
            con.Close();
        }



        

    }
}
