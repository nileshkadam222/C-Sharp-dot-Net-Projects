using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class addbook : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(Database.ConnectionString);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("  select isnull(max(bookid),0) + 1 from books", con);
            int bookid = (int)cmd.ExecuteScalar();

            // upload file 
            String filename = Request.PhysicalApplicationPath + "/books/" + bookid.ToString() + ".pdf";
            if (!FileUpload1.HasFile)
            {
                lblMsg.Text = "Please select a PDF file to upload!";
                return;
            }

            FileUpload1.SaveAs(filename);
            // insert  a row into BOOKS
            cmd.CommandText = "insert into books values(@bookid,@title,@author,@tid,@uid,getdate(),0,0,0,0)";
            cmd.Parameters.Add("@bookid", SqlDbType.Int).Value = bookid;
            cmd.Parameters.Add("@uid", SqlDbType.Int).Value = Session["uid"];
            cmd.Parameters.Add("@title", SqlDbType.VarChar, 50).Value = txtTitle.Text;
            cmd.Parameters.Add("@author", SqlDbType.VarChar, 50).Value = txtAuthor.Text;
            cmd.Parameters.Add("@tid", SqlDbType.Int).Value = ddlTopic.SelectedItem.Value;
            cmd.ExecuteNonQuery();
            lblMsg.Text = "Book has been added successfully!";
        }
        catch (Exception ex)
        {
            lblMsg.Text = "Error -->" + ex.Message;
        }
        finally
        {
            con.Close();
        }

    }
}
