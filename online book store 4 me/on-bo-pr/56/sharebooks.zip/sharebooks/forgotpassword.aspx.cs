using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Net.Mail;


public partial class forgotpassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(Database.ConnectionString);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select pwd from users where email = @email", con);
            cmd.Parameters.Add("@email", SqlDbType.VarChar, 50).Value = txtEmail.Text;

            Object pwd = cmd.ExecuteScalar();
            if (pwd == null)
                lblMsg.Text = "Sorry! Email not found in database!";
            else
            {
                // send mail
                MailMessage m = new MailMessage();
                m.To.Add(new MailAddress(txtEmail.Text));
                m.From = new MailAddress("admin@classroom.com");
                m.Subject = "Password Recovery";
                m.IsBodyHtml = true;
                m.Body = "Dear User,<p/>Please use the following password to login.<p/>Password : " + pwd + "<p/>Webmaster,<br/>www.sharebooks.com";
                SmtpClient client = new SmtpClient("localhost");
                client.Send(m);
                lblMsg.Text = "Mail is sent to your account. Please use those details to login!";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = "Error -->" + ex.Message;
        }
        finally
        {
            con.Close();
        }
    }
}
