using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void GridView1_RowDeleted(object sender, GridViewDeletedEventArgs e)
    {
        String bookid = e.Keys[0].ToString();
        // delete file from BOOKS folder
        String filename = Request.PhysicalApplicationPath + "/books/" + bookid + ".pdf";
        File.Delete(filename);
        lblMsg.Text = "Title [" + e.Values[0].ToString() + "] with id [" + bookid + "] was deleted";
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        // Response.Write(e.Values.Count);
    }
}
