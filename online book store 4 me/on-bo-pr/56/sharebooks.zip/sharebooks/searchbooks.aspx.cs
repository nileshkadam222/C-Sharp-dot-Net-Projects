using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class searchbooks : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        String cond = " 1 = 1  ";
        if (txtTitle.Text.Length > 0)
            cond += " and  title like '%" + txtTitle.Text + "%'";

        if (txtAuthor.Text.Length > 0)
            cond += " and  author like '%" + txtAuthor.Text + "%'";

        if (txtTopic.Text.Length > 0)
            cond += " and  tname like '%" + txtTopic.Text + "%'";

        if (txtFrom.Text.Length > 0)
            cond += " and  uploadedon >='" + txtFrom.Text + "'";

        if (txtTo.Text.Length > 0)
            cond += " and  uploadedon <='" + txtTo.Text + "'";
        // retrieve data from database 
        SqlConnection con = new SqlConnection(Database.ConnectionString);
        SqlDataAdapter da = new SqlDataAdapter("select  bookid,title,author,tname,email, convert(varchar(10),uploadedon,3) uploadedon, DBO.getrating(excellent,good,average,poor) rating from books , topics, users where books.tid = topics.tid and books.uid = users.uid and " + cond, con);
        DataSet ds = new DataSet();
        da.Fill(ds, "books");

        // bind data to gridview
        GridView1.DataSource = ds.Tables[0];
        GridView1.DataBind();

    }
}
